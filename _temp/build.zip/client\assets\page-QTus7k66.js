import{default as i}from"./page-DjwM0_eL.js";import"./index-BBR7LY95.js";import"./chunk-5KNZJZUH-O4cCA1-k.js";import"./layout-5iR72Bj0.js";export{i as default};

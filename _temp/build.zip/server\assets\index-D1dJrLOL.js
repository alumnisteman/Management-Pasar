import { AsyncLocalStorage } from 'node:async_hooks';
import nodeConsole from 'node:console';
import { skipCSRFCheck } from '@auth/core';
import Credentials from '@auth/core/providers/credentials';
import { initAuthConfig, authHandler } from '@hono/auth-js';
import { neon, neonConfig, Pool } from '@neondatabase/serverless';
import { verify, hash } from 'argon2';
import { Hono } from 'hono';
import { contextStorage } from 'hono/context-storage';
import { cors } from 'hono/cors';
import { proxy } from 'hono/proxy';
import { bodyLimit } from 'hono/body-limit';
import { requestId } from 'hono/request-id';
import { createMiddleware } from 'hono/factory';
import { serve } from '@hono/node-server';
import { serveStatic } from '@hono/node-server/serve-static';
import { logger } from 'hono/logger';
import { createRequestHandler } from 'react-router';
import { serializeError } from 'serialize-error';
import ws from 'ws';
import { getToken } from '@auth/core/jwt';
import React from 'react';
import path, { join } from 'node:path';
import { renderToString } from 'react-dom/server';
import { readdirSync, statSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { route, index as index$1 } from '@react-router/dev/routes';
import cleanStack from 'clean-stack';

var defaultWebSocket = {
  upgradeWebSocket: (() => {
  }),
  injectWebSocket: (server) => server
};
async function createWebSocket({ app, enabled }) {
  if (!enabled) {
    return defaultWebSocket;
  }
  process.env.NODE_ENV === "development" ? "development" : "production";
  {
    const { createNodeWebSocket } = await import('@hono/node-ws');
    const { injectWebSocket, upgradeWebSocket } = createNodeWebSocket({ app });
    return {
      upgradeWebSocket,
      injectWebSocket(server) {
        injectWebSocket(server);
        return server;
      }
    };
  }
}
function cleanUpgradeListeners(httpServer) {
  const upgradeListeners = httpServer.listeners("upgrade").filter((listener) => listener.name !== "hmrServerWsListener");
  for (const listener of upgradeListeners) {
    httpServer.removeListener(
      "upgrade",
      /* @ts-expect-error - we don't care */
      listener
    );
  }
}
function patchUpgradeListener(httpServer) {
  const upgradeListeners = httpServer.listeners("upgrade").filter((listener) => listener.name !== "hmrServerWsListener");
  for (const listener of upgradeListeners) {
    httpServer.removeListener(
      "upgrade",
      /* @ts-expect-error - we don't care */
      listener
    );
    httpServer.on("upgrade", (request, ...rest) => {
      if (request.headers["sec-websocket-protocol"] === "vite-hmr") {
        return;
      }
      return listener(request, ...rest);
    });
  }
}
function bindIncomingRequestSocketInfo() {
  return createMiddleware((c, next) => {
    c.env.server = {
      incoming: {
        socket: {
          remoteAddress: c.req.raw.headers.get("x-remote-address") || void 0,
          remotePort: Number(c.req.raw.headers.get("x-remote-port")) || void 0,
          remoteFamily: c.req.raw.headers.get("x-remote-family") || void 0
        }
      }
    };
    return next();
  });
}
async function importBuild() {
  return await import(
    // @ts-expect-error - Virtual module provided by React Router at build time
    './server-build.js'
  );
}
function getBuildMode() {
  return process.env.NODE_ENV === "development" ? "development" : "production";
}

// src/middleware.ts
function cache(seconds) {
  return createMiddleware(async (c, next) => {
    if (!c.req.path.match(/\.[a-zA-Z0-9]+$/) || c.req.path.endsWith(".data")) {
      return next();
    }
    await next();
    if (!c.res.ok || c.res.headers.has("cache-control")) {
      return;
    }
    c.res.headers.set("cache-control", `public, max-age=${seconds}`);
  });
}

async function createHonoServer(options) {
  const startTime = Date.now();
  const build = await importBuild();
  const basename = "/";
  const mergedOptions = {
    ...options,
    listeningListener: options?.listeningListener || ((info) => {
      console.log(`🚀 Server started on port ${info.port}`);
      console.log(`🌍 http://127.0.0.1:${info.port}`);
      console.log(`🏎️ Server started in ${Date.now() - startTime}ms`);
    }),
    port: options?.port || Number(process.env.PORT) || 3e3,
    defaultLogger: options?.defaultLogger ?? true,
    overrideGlobalObjects: options?.overrideGlobalObjects ?? false
  };
  const mode = getBuildMode();
  const PRODUCTION = mode === "production";
  const clientBuildPath = `${"build"}/client`;
  const app = new Hono(mergedOptions.app);
  const { upgradeWebSocket, injectWebSocket } = await createWebSocket({
    app,
    enabled: mergedOptions.useWebSocket ?? false
  });
  if (!PRODUCTION) {
    app.use(bindIncomingRequestSocketInfo());
  }
  await mergedOptions.beforeAll?.(app);
  app.use(
    `/${"assets"}/*`,
    cache(60 * 60 * 24 * 365),
    // 1 year
    serveStatic({ root: clientBuildPath, ...mergedOptions.serveStaticOptions?.clientAssets })
  );
  app.use(
    "*",
    cache(60 * 60),
    // 1 hour
    serveStatic({ root: PRODUCTION ? clientBuildPath : "./public", ...mergedOptions.serveStaticOptions?.publicAssets })
  );
  if (mergedOptions.defaultLogger) {
    app.use("*", logger());
  }
  if (mergedOptions.useWebSocket) {
    await mergedOptions.configure(app, { upgradeWebSocket });
  } else {
    await mergedOptions.configure?.(app);
  }
  const reactRouterApp = new Hono({
    strict: false
  });
  reactRouterApp.use((c, next) => {
    return createMiddleware(async (c2) => {
      const requestHandler = createRequestHandler(build, mode);
      const loadContext = mergedOptions.getLoadContext?.(c2, { build, mode });
      return requestHandler(c2.req.raw, loadContext instanceof Promise ? await loadContext : loadContext);
    })(c, next);
  });
  app.route(`${basename}`, reactRouterApp);
  {
    app.route(`${basename}.data`, reactRouterApp);
  }
  if (PRODUCTION) {
    const server = serve(
      {
        ...app,
        ...mergedOptions.customNodeServer,
        port: mergedOptions.port,
        overrideGlobalObjects: mergedOptions.overrideGlobalObjects,
        hostname: mergedOptions.hostname
      },
      mergedOptions.listeningListener
    );
    mergedOptions.onServe?.(server);
    injectWebSocket(server);
  } else if (globalThis.__viteDevServer?.httpServer) {
    const httpServer = globalThis.__viteDevServer.httpServer;
    cleanUpgradeListeners(httpServer);
    mergedOptions.onServe?.(httpServer);
    injectWebSocket(httpServer);
    patchUpgradeListener(httpServer);
    console.log("🚧 Dev server started");
  }
  return app;
}

function NeonAdapter(client) {
  return {
    async createVerificationToken(verificationToken) {
      const { identifier, expires, token } = verificationToken;
      const sql = `
        INSERT INTO auth_verification_token ( identifier, expires, token )
        VALUES ($1, $2, $3)
        `;
      await client.query(sql, [identifier, expires, token]);
      return verificationToken;
    },
    async useVerificationToken({
      identifier,
      token
    }) {
      const sql = `delete from auth_verification_token
      where identifier = $1 and token = $2
      RETURNING identifier, expires, token `;
      const result = await client.query(sql, [identifier, token]);
      return result.rowCount !== 0 ? result.rows[0] : null;
    },
    async createUser(user) {
      const { name, email, emailVerified, image } = user;
      const sql = `
        INSERT INTO auth_users (name, email, "emailVerified", image)
        VALUES ($1, $2, $3, $4)
        RETURNING id, name, email, "emailVerified", image`;
      const result = await client.query(sql, [
        name,
        email,
        emailVerified,
        image
      ]);
      return result.rows[0];
    },
    async getUser(id) {
      const sql = "select * from auth_users where id = $1";
      try {
        const result = await client.query(sql, [id]);
        return result.rowCount === 0 ? null : result.rows[0];
      } catch {
        return null;
      }
    },
    async getUserByEmail(email) {
      const sql = "select * from auth_users where email = $1";
      const result = await client.query(sql, [email]);
      if (result.rowCount === 0) {
        return null;
      }
      const userData = result.rows[0];
      const accountsData = await client.query(
        'select * from auth_accounts where "userId" = $1',
        [userData.id]
      );
      return {
        ...userData,
        accounts: accountsData.rows
      };
    },
    async getUserByAccount({
      providerAccountId,
      provider
    }) {
      const sql = `
          select u.* from auth_users u join auth_accounts a on u.id = a."userId"
          where
          a.provider = $1
          and
          a."providerAccountId" = $2`;
      const result = await client.query(sql, [provider, providerAccountId]);
      return result.rowCount !== 0 ? result.rows[0] : null;
    },
    async updateUser(user) {
      const fetchSql = "select * from auth_users where id = $1";
      const query1 = await client.query(fetchSql, [user.id]);
      const oldUser = query1.rows[0];
      const newUser = {
        ...oldUser,
        ...user
      };
      const { id, name, email, emailVerified, image } = newUser;
      const updateSql = `
        UPDATE auth_users set
        name = $2, email = $3, "emailVerified" = $4, image = $5
        where id = $1
        RETURNING name, id, email, "emailVerified", image
      `;
      const query2 = await client.query(updateSql, [
        id,
        name,
        email,
        emailVerified,
        image
      ]);
      return query2.rows[0];
    },
    async linkAccount(account) {
      const sql = `
      insert into auth_accounts
      (
        "userId",
        provider,
        type,
        "providerAccountId",
        access_token,
        expires_at,
        refresh_token,
        id_token,
        scope,
        session_state,
        token_type,
        password
      )
      values ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
      returning
        id,
        "userId",
        provider,
        type,
        "providerAccountId",
        access_token,
        expires_at,
        refresh_token,
        id_token,
        scope,
        session_state,
        token_type,
        password
      `;
      const params = [
        account.userId,
        account.provider,
        account.type,
        account.providerAccountId,
        account.access_token,
        account.expires_at,
        account.refresh_token,
        account.id_token,
        account.scope,
        account.session_state,
        account.token_type,
        account.extraData?.password
      ];
      const result = await client.query(sql, params);
      return result.rows[0];
    },
    async createSession({ sessionToken, userId, expires }) {
      if (userId === void 0) {
        throw Error("userId is undef in createSession");
      }
      const sql = `insert into auth_sessions ("userId", expires, "sessionToken")
      values ($1, $2, $3)
      RETURNING id, "sessionToken", "userId", expires`;
      const result = await client.query(sql, [userId, expires, sessionToken]);
      return result.rows[0];
    },
    async getSessionAndUser(sessionToken) {
      if (sessionToken === void 0) {
        return null;
      }
      const result1 = await client.query(
        `select * from auth_sessions where "sessionToken" = $1`,
        [sessionToken]
      );
      if (result1.rowCount === 0) {
        return null;
      }
      const session = result1.rows[0];
      const result2 = await client.query(
        "select * from auth_users where id = $1",
        [session.userId]
      );
      if (result2.rowCount === 0) {
        return null;
      }
      const user = result2.rows[0];
      return {
        session,
        user
      };
    },
    async updateSession(session) {
      const { sessionToken } = session;
      const result1 = await client.query(
        `select * from auth_sessions where "sessionToken" = $1`,
        [sessionToken]
      );
      if (result1.rowCount === 0) {
        return null;
      }
      const originalSession = result1.rows[0];
      const newSession = {
        ...originalSession,
        ...session
      };
      const sql = `
        UPDATE auth_sessions set
        expires = $2
        where "sessionToken" = $1
        `;
      const result = await client.query(sql, [
        newSession.sessionToken,
        newSession.expires
      ]);
      return result.rows[0];
    },
    async deleteSession(sessionToken) {
      const sql = `delete from auth_sessions where "sessionToken" = $1`;
      await client.query(sql, [sessionToken]);
    },
    async unlinkAccount(partialAccount) {
      const { provider, providerAccountId } = partialAccount;
      const sql = `delete from auth_accounts where "providerAccountId" = $1 and provider = $2`;
      await client.query(sql, [providerAccountId, provider]);
    },
    async deleteUser(userId) {
      await client.query("delete from auth_users where id = $1", [userId]);
      await client.query('delete from auth_sessions where "userId" = $1', [
        userId
      ]);
      await client.query('delete from auth_accounts where "userId" = $1', [
        userId
      ]);
    }
  };
}

const getHTMLForErrorPage = (err) => {
  return `
<html>
  <head>
    <script>
    window.onload = () => {
      const error = ${JSON.stringify(serializeError(err))};
      window.parent.postMessage({ type: 'sandbox:web:ready' }, '*');
      window.parent.postMessage({ type: 'sandbox:error:detected', error: error }, '*');

      const healthyResponse = {
        type: 'sandbox:web:healthcheck:response',
        healthy: true,
        hasError: true,
        supportsErrorDetected: true,
      };
      window.addEventListener('message', (event) => {
        if (event.data.type === 'sandbox:navigation') {
          window.location.pathname = event.data.pathname;
        }
        if (event.data.type === 'sandbox:web:healthcheck') {
          window.parent.postMessage(healthyResponse, '*');
        }
      });
      console.error(error);
    }
    <\/script>
  </head>
  <body></body>
</html>
    `;
};

const authActions = [
  "providers",
  "session",
  "csrf",
  "signin",
  "signout",
  "callback",
  "verify-request",
  "error",
  "webauthn-options"
];
function isAuthAction(pathname) {
  const base = "/api/auth";
  const a = pathname.match(new RegExp(`^${base}(.+)`));
  if (a === null) {
    return false;
  }
  const actionAndProviderId = a.at(-1);
  if (!actionAndProviderId) {
    return false;
  }
  const b = actionAndProviderId.replace(/^\//, "").split("/").filter(Boolean);
  if (b.length !== 1 && b.length !== 2) {
    return false;
  }
  const [action] = b;
  if (!authActions.includes(action)) {
    return false;
  }
  return true;
}

const ALLOWED_PROVIDERS = new Set(['google', 'facebook', 'twitter', 'apple']);
function GET$e(request) {
  if (process.env.NEXT_PUBLIC_CREATE_ENV !== 'DEVELOPMENT') {
    return Response.json({
      error: 'not found'
    }, {
      status: 404
    });
  }
  const url = new URL(request.url);
  const provider = url.searchParams.get('provider');
  if (!provider || !ALLOWED_PROVIDERS.has(provider.toLowerCase())) {
    return Response.json({
      error: 'invalid provider'
    }, {
      status: 400
    });
  }
  const key = provider.toUpperCase();
  const clientId = `${key}_CLIENT_ID`;
  const clientSecret = `${key}_CLIENT_SECRET`;
  const missing = [];
  if (!process.env[clientId]) missing.push(clientId);
  if (!process.env[clientSecret]) missing.push(clientSecret);
  return Response.json({
    provider,
    missing
  });
}

const __vite_glob_0_0 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  GET: GET$e
}, Symbol.toStringTag, { value: 'Module' }));

const __dirname$1 = fileURLToPath(new URL(".", import.meta.url));
function buildRouteTree(dir, basePath = "") {
  const files = readdirSync(dir);
  const node = {
    path: basePath,
    children: [],
    hasPage: false,
    isParam: false,
    isCatchAll: false,
    paramName: ""
  };
  const dirName = basePath.split("/").pop();
  if (dirName?.startsWith("[") && dirName.endsWith("]")) {
    node.isParam = true;
    const paramName = dirName.slice(1, -1);
    if (paramName.startsWith("...")) {
      node.isCatchAll = true;
      node.paramName = paramName.slice(3);
    } else {
      node.paramName = paramName;
    }
  }
  for (const file of files) {
    const filePath = join(dir, file);
    const stat = statSync(filePath);
    if (stat.isDirectory()) {
      const childPath = basePath ? `${basePath}/${file}` : file;
      const childNode = buildRouteTree(filePath, childPath);
      node.children.push(childNode);
    } else if (file === "page.jsx") {
      node.hasPage = true;
    }
  }
  return node;
}
function generateRoutes(node) {
  const routes2 = [];
  if (node.hasPage) {
    const componentPath = node.path === "" ? `./${node.path}page.jsx` : `./${node.path}/page.jsx`;
    if (node.path === "") {
      routes2.push(index$1(componentPath));
    } else {
      let routePath = node.path;
      const segments = routePath.split("/");
      const processedSegments = segments.map((segment) => {
        if (segment.startsWith("[") && segment.endsWith("]")) {
          const paramName = segment.slice(1, -1);
          if (paramName.startsWith("...")) {
            return "*";
          }
          if (paramName.startsWith("[") && paramName.endsWith("]")) {
            return `:${paramName.slice(1, -1)}?`;
          }
          return `:${paramName}`;
        }
        return segment;
      });
      routePath = processedSegments.join("/");
      routes2.push(route(routePath, componentPath));
    }
  }
  for (const child of node.children) {
    routes2.push(...generateRoutes(child));
  }
  return routes2;
}
const tree = buildRouteTree(__dirname$1);
const notFound = route("*?", "./__create/not-found.tsx");
const routes = [...generateRoutes(tree), notFound];

function serializeClean(err) {
  // if we want to clean this more, maybe we should look at the file where it
  // is imported and above.
  err.stack = cleanStack(err.stack, {
    pathFilter: path => {
      // Filter out paths that are not relevant to the error
      return !path.includes('node_modules') && !path.includes('dist') && !path.includes('__create');
    }
  });
  return serializeError(err);
}
const getHTMLOrError = component => {
  try {
    const html = renderToString(React.createElement(component, {}));
    return {
      html,
      error: null
    };
  } catch (error) {
    return {
      html: null,
      error: serializeClean(error)
    };
  }
};
async function GET$d(request) {
  const results = await Promise.allSettled(routes.map(async route => {
    let component = null;
    try {
      const response = await import(/* @vite-ignore */path.join('../../../', route.file));
      component = response.default;
    } catch (error) {
      console.debug('Error importing component:', route.file, error);
    }
    if (!component) {
      return null;
    }
    getHTMLOrError(component);
    return {
      route: route.file,
      path: route.path,
      ...getHTMLOrError(component)
    };
  }));
  const cleanedResults = results.filter(result => result.status === 'fulfilled').map(result => {
    if (result.status === 'fulfilled') {
      return result.value;
    }
    return null;
  }).filter(result => result !== null);
  return Response.json({
    results: cleanedResults
  });
}

const __vite_glob_0_1 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  GET: GET$d
}, Symbol.toStringTag, { value: 'Module' }));

const NullishQueryFunction = () => {
  throw new Error('No database connection string was provided to `neon()`. Perhaps process.env.DATABASE_URL has not been set');
};
NullishQueryFunction.transaction = () => {
  throw new Error('No database connection string was provided to `neon()`. Perhaps process.env.DATABASE_URL has not been set');
};
const sql = process.env.DATABASE_URL ? neon(process.env.DATABASE_URL) : NullishQueryFunction;

async function GET$c(request) {
  try {
    const {
      searchParams
    } = new URL(request.url);
    const module = searchParams.get("module") || "";
    const limit = parseInt(searchParams.get("limit") || "50");
    let query = `SELECT * FROM audit_logs WHERE 1=1`;
    const values = [];
    let idx = 1;
    if (module) {
      query += ` AND module = $${idx}`;
      values.push(module);
      idx++;
    }
    query += ` ORDER BY created_at DESC LIMIT $${idx}`;
    values.push(limit);
    const rows = await sql(query, values);
    return Response.json(rows);
  } catch (error) {
    console.error(error);
    return Response.json({
      error: "Failed to fetch audit logs"
    }, {
      status: 500
    });
  }
}
async function POST$9(request) {
  try {
    const body = await request.json();
    const {
      module,
      action,
      user_name,
      description,
      ip_address
    } = body;
    const row = await sql`
      INSERT INTO audit_logs (module, action, user_name, description, ip_address)
      VALUES (${module}, ${action}, ${user_name || "Admin"}, ${description}, ${ip_address || "127.0.0.1"})
      RETURNING *
    `;
    return Response.json(row[0]);
  } catch (error) {
    console.error(error);
    return Response.json({
      error: "Failed to create log"
    }, {
      status: 500
    });
  }
}

const __vite_glob_0_2 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  GET: GET$c,
  POST: POST$9
}, Symbol.toStringTag, { value: 'Module' }));

async function GET$b(request) {
  try {
    const {
      searchParams
    } = new URL(request.url);
    const month = searchParams.get("month") || "";
    const status = searchParams.get("status") || "";
    let query = `
      SELECT b.*, t.name as trader_name, t.phone, s.stall_code, s.zone
      FROM bills b
      JOIN traders t ON b.trader_id = t.id
      LEFT JOIN stalls s ON b.stall_id = s.id
      WHERE 1=1
    `;
    const values = [];
    let idx = 1;
    if (month) {
      query += ` AND b.bill_month = $${idx}`;
      values.push(month);
      idx++;
    }
    if (status) {
      query += ` AND b.status = $${idx}`;
      values.push(status);
      idx++;
    }
    query += ` ORDER BY b.created_at DESC`;
    const rows = await sql(query, values);
    return Response.json(rows);
  } catch (error) {
    console.error(error);
    return Response.json({
      error: "Failed to fetch bills"
    }, {
      status: 500
    });
  }
}
async function POST$8(request) {
  try {
    const body = await request.json();
    const {
      bill_month
    } = body;

    // Generate bills for all active traders who don't have one yet this month
    const traders = await sql`
      SELECT t.id, t.stall_id, s.monthly_fee
      FROM traders t
      JOIN stalls s ON t.stall_id = s.id
      WHERE t.status = 'active'
        AND NOT EXISTS (
          SELECT 1 FROM bills b WHERE b.trader_id = t.id AND b.bill_month = ${bill_month}
        )
    `;
    let created = 0;
    for (const t of traders) {
      await sql`
        INSERT INTO bills (trader_id, stall_id, bill_month, amount, status)
        VALUES (${t.id}, ${t.stall_id}, ${bill_month}, ${t.monthly_fee}, 'unpaid')
      `;
      created++;
    }
    await sql`
      INSERT INTO audit_logs (module, action, description)
      VALUES ('Billing', 'GENERATE', ${`Tagihan ${bill_month} dibuat untuk ${created} pedagang`})
    `;
    return Response.json({
      created,
      month: bill_month
    });
  } catch (error) {
    console.error(error);
    return Response.json({
      error: "Failed to generate bills"
    }, {
      status: 500
    });
  }
}
async function PATCH$6(request) {
  try {
    const body = await request.json();
    const {
      id,
      trader_name
    } = body;
    const updated = await sql`
      UPDATE bills SET status = 'paid', paid_at = NOW()
      WHERE id = ${id}
      RETURNING *
    `;
    await sql`
      INSERT INTO audit_logs (module, action, description)
      VALUES ('Billing', 'PAYMENT', ${`Tagihan lunas - ${trader_name || "Pedagang"}`})
    `;
    return Response.json(updated[0]);
  } catch (error) {
    console.error(error);
    return Response.json({
      error: "Failed to mark bill as paid"
    }, {
      status: 500
    });
  }
}

const __vite_glob_0_3 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  GET: GET$b,
  PATCH: PATCH$6,
  POST: POST$8
}, Symbol.toStringTag, { value: 'Module' }));

async function GET$a(request) {
  try {
    const {
      searchParams
    } = new URL(request.url);
    const status = searchParams.get("status") || "";
    const token = searchParams.get("token") || "";

    // QR verification
    if (token) {
      const rows = await sql`
        SELECT p.*, t.name as trader_name, t.phone, t.trader_type,
               s.stall_code, s.zone, s.category
        FROM permits p
        JOIN traders t ON p.trader_id = t.id
        LEFT JOIN stalls s ON t.stall_id = s.id
        WHERE p.qr_token = ${token}
      `;
      if (!rows[0]) return Response.json({
        valid: false
      });
      return Response.json({
        valid: true,
        permit: rows[0]
      });
    }
    let query = `
      SELECT p.*, t.name as trader_name, t.phone, s.stall_code, s.zone
      FROM permits p
      JOIN traders t ON p.trader_id = t.id
      LEFT JOIN stalls s ON t.stall_id = s.id
      WHERE 1=1
    `;
    const values = [];
    let idx = 1;
    if (status) {
      query += ` AND p.status = $${idx}`;
      values.push(status);
      idx++;
    }
    query += ` ORDER BY p.created_at DESC`;
    const rows = await sql(query, values);
    return Response.json(rows);
  } catch (error) {
    console.error(error);
    return Response.json({
      error: "Failed to fetch permits"
    }, {
      status: 500
    });
  }
}
async function POST$7(request) {
  try {
    const body = await request.json();
    const {
      trader_id,
      expiry_date
    } = body;
    const trader = await sql`SELECT * FROM traders WHERE id = ${trader_id}`;
    if (!trader[0]) return Response.json({
      error: "Trader not found"
    }, {
      status: 404
    });
    const year = new Date().getFullYear();
    const existingCount = await sql`SELECT COUNT(*) as cnt FROM permits WHERE permit_number LIKE ${`SIPTU-${year}-%`}`;
    const seq = Number(existingCount[0].cnt) + 1;
    const permitNum = `SIPTU-${year}-${String(seq).padStart(4, "0")}`;
    const issueDate = new Date().toISOString().split("T")[0];
    const qrToken = Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2);
    const permit = await sql`
      INSERT INTO permits (trader_id, permit_number, issue_date, expiry_date, status, qr_token)
      VALUES (${trader_id}, ${permitNum}, ${issueDate}, ${expiry_date}, 'active', ${qrToken})
      RETURNING *
    `;
    await sql`
      INSERT INTO audit_logs (module, action, description)
      VALUES ('SIPTU', 'CREATE', ${`SIPTU ${permitNum} diterbitkan untuk ${trader[0].name}`})
    `;
    return Response.json(permit[0]);
  } catch (error) {
    console.error(error);
    return Response.json({
      error: "Failed to create permit"
    }, {
      status: 500
    });
  }
}
async function PATCH$5(request) {
  try {
    const body = await request.json();
    const {
      id,
      status,
      expiry_date
    } = body;
    const updated = await sql`
      UPDATE permits SET
        status = COALESCE(${status}, status),
        expiry_date = COALESCE(${expiry_date ?? null}, expiry_date)
      WHERE id = ${id}
      RETURNING *
    `;
    await sql`
      INSERT INTO audit_logs (module, action, description)
      VALUES ('SIPTU', 'UPDATE', ${`SIPTU #${id} diperbarui`})
    `;
    return Response.json(updated[0]);
  } catch (error) {
    console.error(error);
    return Response.json({
      error: "Failed to update permit"
    }, {
      status: 500
    });
  }
}

const __vite_glob_0_4 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  GET: GET$a,
  PATCH: PATCH$5,
  POST: POST$7
}, Symbol.toStringTag, { value: 'Module' }));

function fmtRp(n) {
  return "Rp " + Number(n || 0).toLocaleString("id-ID");
}
function fmtDate(d) {
  if (!d) return "—";
  return new Date(d).toLocaleDateString("id-ID", {
    day: "2-digit",
    month: "long",
    year: "numeric"
  });
}

// Build billing report HTML
async function buildBillingHTML(month) {
  const bills = await sql`
    SELECT b.*, t.name as trader_name, t.phone, s.stall_code, s.zone
    FROM bills b
    JOIN traders t ON b.trader_id = t.id
    LEFT JOIN stalls s ON b.stall_id = s.id
    WHERE b.bill_month = ${month}
    ORDER BY t.name ASC
  `;
  const totalBilled = bills.reduce((s, b) => s + Number(b.amount), 0);
  const totalPaid = bills.filter(b => b.status === "paid").reduce((s, b) => s + Number(b.amount), 0);
  const paidCount = bills.filter(b => b.status === "paid").length;
  const compRate = bills.length > 0 ? Math.round(paidCount / bills.length * 100) : 0;
  const rows = bills.map(b => `
    <tr style="border-bottom:1px solid #e5e7eb;">
      <td style="padding:10px 12px;">${b.trader_name}</td>
      <td style="padding:10px 12px; font-family:monospace; font-size:12px;">${b.stall_code || "—"}</td>
      <td style="padding:10px 12px; text-transform:capitalize;">${b.zone || "—"}</td>
      <td style="padding:10px 12px;">${fmtRp(b.amount)}</td>
      <td style="padding:10px 12px;">
        <span style="background:${b.status === "paid" ? "#dcfce7" : "#fee2e2"};color:${b.status === "paid" ? "#166534" : "#991b1b"};padding:2px 8px;border-radius:999px;font-size:11px;font-weight:600;">
          ${b.status === "paid" ? "Lunas" : "Belum Bayar"}
        </span>
      </td>
      <td style="padding:10px 12px; font-size:12px; color:#6b7280;">${b.paid_at ? fmtDate(b.paid_at) : "—"}</td>
    </tr>
  `).join("");
  return `<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8">
  <style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { font-family: 'Segoe UI', sans-serif; color: #111827; background: white; padding: 40px; }
    .header { border-bottom: 3px solid #1d4ed8; padding-bottom: 20px; margin-bottom: 28px; }
    .title { font-size: 22px; font-weight: 700; color: #1d4ed8; }
    .subtitle { font-size: 13px; color: #6b7280; margin-top: 4px; }
    .kpi { display: flex; gap: 16px; margin-bottom: 28px; }
    .kpi-box { flex: 1; background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 10px; padding: 16px; }
    .kpi-label { font-size: 11px; text-transform: uppercase; letter-spacing: .05em; color: #6b7280; font-weight: 600; }
    .kpi-val { font-size: 20px; font-weight: 700; margin-top: 4px; }
    table { width: 100%; border-collapse: collapse; font-size: 13px; }
    thead { background: #1d4ed8; color: white; }
    th { padding: 10px 12px; text-align: left; font-size: 11px; text-transform: uppercase; letter-spacing: .05em; }
    tr:nth-child(even) { background: #f9fafb; }
    .footer { margin-top: 32px; text-align: center; font-size: 11px; color: #9ca3af; }
    .compliance { color: ${compRate >= 80 ? "#166534" : compRate >= 50 ? "#92400e" : "#991b1b"}; }
  </style></head><body>
  <div class="header">
    <div class="title">📊 Laporan Tagihan Bulanan — ${month}</div>
    <div class="subtitle">SVMS v6.0 Enterprise · Dicetak: ${fmtDate(new Date())}</div>
  </div>
  <div class="kpi">
    <div class="kpi-box"><div class="kpi-label">Total Ditagihkan</div><div class="kpi-val">${fmtRp(totalBilled)}</div></div>
    <div class="kpi-box"><div class="kpi-label">Terkumpul</div><div class="kpi-val" style="color:#166534;">${fmtRp(totalPaid)}</div></div>
    <div class="kpi-box"><div class="kpi-label">Compliance Rate</div><div class="kpi-val compliance">${compRate}%</div></div>
    <div class="kpi-box"><div class="kpi-label">Total Tagihan</div><div class="kpi-val">${bills.length} tagihan</div></div>
  </div>
  <table>
    <thead><tr>
      <th>Pedagang</th><th>Kode Lapak</th><th>Zona</th><th>Nominal</th><th>Status</th><th>Tgl Bayar</th>
    </tr></thead>
    <tbody>${rows}</tbody>
  </table>
  <div class="footer">Dokumen ini digenerate otomatis oleh SVMS v6.0 Enterprise · ${fmtDate(new Date())}</div>
  </body></html>`;
}

// Build traders report HTML
async function buildTradersHTML() {
  const traders = await sql`
    SELECT t.*, s.stall_code, s.zone, s.category, s.monthly_fee,
           p.permit_number, p.status as permit_status, p.expiry_date
    FROM traders t
    LEFT JOIN stalls s ON t.stall_id = s.id
    LEFT JOIN permits p ON p.trader_id = t.id
    ORDER BY t.name ASC
  `;
  const total = traders.length;
  const active = traders.filter(t => t.status === "active").length;
  const withPermit = traders.filter(t => t.permit_number).length;
  const rows = traders.map(t => `
    <tr style="border-bottom:1px solid #e5e7eb;">
      <td style="padding:10px 12px; font-weight:500;">${t.name}</td>
      <td style="padding:10px 12px; font-size:12px;">${t.nik || "—"}</td>
      <td style="padding:10px 12px; font-size:12px;">${t.phone || "—"}</td>
      <td style="padding:10px 12px; text-transform:capitalize;">${t.trader_type}</td>
      <td style="padding:10px 12px; font-family:monospace; font-size:12px;">${t.stall_code || "—"}</td>
      <td style="padding:10px 12px;">
        <span style="background:${t.status === "active" ? "#dcfce7" : t.status === "warning" ? "#fef3c7" : "#f3f4f6"};
          color:${t.status === "active" ? "#166534" : t.status === "warning" ? "#92400e" : "#374151"};
          padding:2px 8px;border-radius:999px;font-size:11px;font-weight:600;">
          ${t.status === "active" ? "Aktif" : t.status === "warning" ? "Peringatan" : "Nonaktif"}
        </span>
      </td>
      <td style="padding:10px 12px; font-size:12px;">${t.permit_number || "Belum ada"}</td>
    </tr>
  `).join("");
  return `<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8">
  <style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { font-family: 'Segoe UI', sans-serif; color: #111827; background: white; padding: 40px; }
    .header { border-bottom: 3px solid #7c3aed; padding-bottom: 20px; margin-bottom: 28px; }
    .title { font-size: 22px; font-weight: 700; color: #7c3aed; }
    .subtitle { font-size: 13px; color: #6b7280; margin-top: 4px; }
    .kpi { display: flex; gap: 16px; margin-bottom: 28px; }
    .kpi-box { flex: 1; background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 10px; padding: 16px; }
    .kpi-label { font-size: 11px; text-transform: uppercase; letter-spacing: .05em; color: #6b7280; font-weight: 600; }
    .kpi-val { font-size: 20px; font-weight: 700; margin-top: 4px; }
    table { width: 100%; border-collapse: collapse; font-size: 13px; }
    thead { background: #7c3aed; color: white; }
    th { padding: 10px 12px; text-align: left; font-size: 11px; text-transform: uppercase; letter-spacing: .05em; }
    tr:nth-child(even) { background: #f9fafb; }
    .footer { margin-top: 32px; text-align: center; font-size: 11px; color: #9ca3af; }
  </style></head><body>
  <div class="header">
    <div class="title">👥 Laporan Data Pedagang</div>
    <div class="subtitle">SVMS v6.0 Enterprise · Dicetak: ${fmtDate(new Date())}</div>
  </div>
  <div class="kpi">
    <div class="kpi-box"><div class="kpi-label">Total Pedagang</div><div class="kpi-val">${total}</div></div>
    <div class="kpi-box"><div class="kpi-label">Aktif</div><div class="kpi-val" style="color:#166534;">${active}</div></div>
    <div class="kpi-box"><div class="kpi-label">Memiliki SIPTU</div><div class="kpi-val">${withPermit}</div></div>
    <div class="kpi-box"><div class="kpi-label">Tanpa SIPTU</div><div class="kpi-val" style="color:#991b1b;">${total - withPermit}</div></div>
  </div>
  <table>
    <thead><tr><th>Nama</th><th>NIK</th><th>Telepon</th><th>Tipe</th><th>Lapak</th><th>Status</th><th>No. SIPTU</th></tr></thead>
    <tbody>${rows}</tbody>
  </table>
  <div class="footer">Dokumen ini digenerate otomatis oleh SVMS v6.0 Enterprise · ${fmtDate(new Date())}</div>
  </body></html>`;
}

// Build porter incentives report HTML
async function buildPorterHTML() {
  const porters = await sql`SELECT * FROM porters ORDER BY rating DESC`;
  const incentives = await sql`
    SELECT pi.*, p.name as porter_name
    FROM porter_incentives pi
    JOIN porters p ON pi.porter_id = p.id
    ORDER BY pi.week_start DESC
    LIMIT 50
  `;
  const rows = porters.map(p => {
    const inc = incentives.find(i => i.porter_id === p.id);
    const tierEmoji = {
      platinum: "💎",
      gold: "🥇",
      silver: "🥈",
      bronze: "🥉"
    };
    return `
    <tr style="border-bottom:1px solid #e5e7eb;">
      <td style="padding:10px 12px; font-weight:500;">${p.name}</td>
      <td style="padding:10px 12px; font-size:12px;">${p.phone}</td>
      <td style="padding:10px 12px;">
        <span style="background:${p.status === "available" ? "#dcfce7" : p.status === "active" ? "#dbeafe" : "#f3f4f6"};
          color:${p.status === "available" ? "#166534" : p.status === "active" ? "#1e40af" : "#374151"};
          padding:2px 8px;border-radius:999px;font-size:11px;font-weight:600;">
          ${p.status === "available" ? "Tersedia" : p.status === "active" ? "Bertugas" : "Off"}
        </span>
      </td>
      <td style="padding:10px 12px; text-align:center;">⭐ ${Number(p.rating).toFixed(1)}</td>
      <td style="padding:10px 12px;">${inc ? `${tierEmoji[inc.tier] || "—"} ${inc.tier}` : "—"}</td>
      <td style="padding:10px 12px;">${inc ? `Rp ${Number(inc.bonus_amount).toLocaleString("id-ID")}` : "—"}</td>
      <td style="padding:10px 12px; font-size:12px;">${inc?.week_start || "—"} s/d ${inc?.week_end || "—"}</td>
    </tr>`;
  }).join("");
  return `<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8">
  <style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { font-family: 'Segoe UI', sans-serif; color: #111827; background: white; padding: 40px; }
    .header { border-bottom: 3px solid #0891b2; padding-bottom: 20px; margin-bottom: 28px; }
    .title { font-size: 22px; font-weight: 700; color: #0891b2; }
    .subtitle { font-size: 13px; color: #6b7280; margin-top: 4px; }
    .kpi { display: flex; gap: 16px; margin-bottom: 28px; }
    .kpi-box { flex: 1; background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 10px; padding: 16px; }
    .kpi-label { font-size: 11px; text-transform: uppercase; letter-spacing: .05em; color: #6b7280; font-weight: 600; }
    .kpi-val { font-size: 20px; font-weight: 700; margin-top: 4px; }
    table { width: 100%; border-collapse: collapse; font-size: 13px; }
    thead { background: #0891b2; color: white; }
    th { padding: 10px 12px; text-align: left; font-size: 11px; text-transform: uppercase; letter-spacing: .05em; }
    tr:nth-child(even) { background: #f9fafb; }
    .footer { margin-top: 32px; text-align: center; font-size: 11px; color: #9ca3af; }
  </style></head><body>
  <div class="header">
    <div class="title">📦 Laporan Kuli Panggul & Insentif</div>
    <div class="subtitle">SVMS v6.0 Enterprise · Dicetak: ${fmtDate(new Date())}</div>
  </div>
  <div class="kpi">
    <div class="kpi-box"><div class="kpi-label">Total Porter</div><div class="kpi-val">${porters.length}</div></div>
    <div class="kpi-box"><div class="kpi-label">Tersedia</div><div class="kpi-val" style="color:#166534;">${porters.filter(p => p.status === "available").length}</div></div>
    <div class="kpi-box"><div class="kpi-label">Rating Avg</div><div class="kpi-val" style="color:#d97706;">⭐ ${porters.length > 0 ? (porters.reduce((s, p) => s + Number(p.rating), 0) / porters.length).toFixed(2) : "5.00"}</div></div>
    <div class="kpi-box"><div class="kpi-label">Punya Insentif</div><div class="kpi-val">${new Set(incentives.map(i => i.porter_id)).size}</div></div>
  </div>
  <table>
    <thead><tr><th>Nama</th><th>Telepon</th><th>Status</th><th>Rating</th><th>Tier Insentif</th><th>Bonus</th><th>Periode</th></tr></thead>
    <tbody>${rows}</tbody>
  </table>
  <div class="footer">Dokumen ini digenerate otomatis oleh SVMS v6.0 Enterprise · ${fmtDate(new Date())}</div>
  </body></html>`;
}
async function POST$6(request) {
  try {
    const body = await request.json();
    const {
      type,
      month
    } = body;
    let html = "";
    let filename = "laporan.pdf";
    if (type === "billing") {
      const m = month || new Date().toISOString().slice(0, 7);
      html = await buildBillingHTML(m);
      filename = `tagihan-${m}.pdf`;
    } else if (type === "traders") {
      html = await buildTradersHTML();
      filename = `pedagang-${new Date().toISOString().slice(0, 10)}.pdf`;
    } else if (type === "porter") {
      html = await buildPorterHTML();
      filename = `porter-insentif-${new Date().toISOString().slice(0, 10)}.pdf`;
    } else {
      return Response.json({
        error: "type must be billing | traders | porter"
      }, {
        status: 400
      });
    }

    // Call PDF generation integration
    const pdfRes = await fetch(`${process.env.NEXT_PUBLIC_CREATE_APP_URL || ""}/integrations/pdf-generation/pdf`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        source: {
          html
        }
      })
    });
    if (!pdfRes.ok) {
      throw new Error(`PDF generation failed: ${pdfRes.status}`);
    }
    const pdfBuffer = await pdfRes.arrayBuffer();

    // Log the action
    await sql`
      INSERT INTO audit_logs (module, action, description)
      VALUES ('Laporan', 'EXPORT', ${`Laporan PDF ${type} digenerate: ${filename}`})
    `;
    return new Response(pdfBuffer, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="${filename}"`
      }
    });
  } catch (error) {
    console.error(error);
    return Response.json({
      error: "Failed to generate PDF: " + error.message
    }, {
      status: 500
    });
  }
}

const __vite_glob_0_5 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  POST: POST$6
}, Symbol.toStringTag, { value: 'Module' }));

// Dynamic pricing rules per zone
const DYNAMIC_PRICING = {
  gold: {
    base: 750000,
    max: 1200000,
    min: 600000,
    multiplier: 0.15
  },
  silver: {
    base: 500000,
    max: 850000,
    min: 400000,
    multiplier: 0.12
  },
  bronze: {
    base: 350000,
    max: 600000,
    min: 280000,
    multiplier: 0.1
  }
};
function calcDynamicPrice(zone, occupancyRate) {
  const rule = DYNAMIC_PRICING[zone] || DYNAMIC_PRICING.silver;
  const price = Math.round(rule.base * (1 + occupancyRate / 100 * rule.multiplier) / 10000) * 10000;
  return Math.min(Math.max(price, rule.min), rule.max);
}
async function GET$9() {
  try {
    const rows = await sql`
      SELECT s.*, t.name as trader_name, t.phone as trader_phone
      FROM stalls s
      LEFT JOIN traders t ON s.trader_id = t.id
      ORDER BY s.row_x ASC, s.col_y ASC
    `;

    // Compute occupancy per zone for dynamic pricing suggestions
    const zoneStats = {};
    rows.forEach(s => {
      if (!zoneStats[s.zone]) zoneStats[s.zone] = {
        total: 0,
        occupied: 0
      };
      zoneStats[s.zone].total++;
      if (s.status === "occupied") zoneStats[s.zone].occupied++;
    });
    const result = rows.map(s => {
      const zs = zoneStats[s.zone] || {
        total: 1,
        occupied: 0
      };
      const occupancyRate = Math.round(zs.occupied / zs.total * 100);
      return {
        ...s,
        suggested_price: calcDynamicPrice(s.zone, occupancyRate),
        zone_occupancy: occupancyRate
      };
    });
    return Response.json(result);
  } catch (error) {
    console.error(error);
    return Response.json({
      error: "Failed to fetch stalls"
    }, {
      status: 500
    });
  }
}
async function PATCH$4(request) {
  try {
    const body = await request.json();
    const {
      id,
      status,
      trader_id,
      zone,
      category,
      monthly_fee,
      apply_dynamic_pricing
    } = body;

    // Apply dynamic pricing to an entire zone
    if (apply_dynamic_pricing && zone) {
      const stats = await sql`
        SELECT COUNT(*) as total, COUNT(*) FILTER (WHERE status = 'occupied') as occupied
        FROM stalls WHERE zone = ${zone}
      `;
      const occupancyRate = Number(stats[0].total) > 0 ? Math.round(Number(stats[0].occupied) / Number(stats[0].total) * 100) : 0;
      const newPrice = calcDynamicPrice(zone, occupancyRate);
      const updated = await sql`
        UPDATE stalls SET monthly_fee = ${newPrice} WHERE zone = ${zone} RETURNING *
      `;
      await sql`
        INSERT INTO audit_logs (module, action, description)
        VALUES ('Grid', 'DYNAMIC_PRICE', ${`Dynamic pricing diterapkan ke zone ${zone}: Rp ${newPrice.toLocaleString("id-ID")} (hunian ${occupancyRate}%)`})
      `;
      return Response.json({
        updated: updated.length,
        new_price: newPrice,
        zone,
        occupancy_rate: occupancyRate
      });
    }

    // Single stall update
    const updated = await sql`
      UPDATE stalls SET
        status = COALESCE(${status ?? null}, status),
        trader_id = ${trader_id !== undefined ? trader_id || null : sql`trader_id`},
        zone = COALESCE(${zone ?? null}, zone),
        category = COALESCE(${category ?? null}, category),
        monthly_fee = COALESCE(${monthly_fee ?? null}, monthly_fee)
      WHERE id = ${id}
      RETURNING *
    `;
    await sql`
      INSERT INTO audit_logs (module, action, description)
      VALUES ('Grid', 'UPDATE', ${`Lapak #${updated[0]?.stall_code} diperbarui`})
    `;
    return Response.json(updated[0]);
  } catch (error) {
    console.error(error);
    return Response.json({
      error: "Failed to update stall"
    }, {
      status: 500
    });
  }
}

const __vite_glob_0_6 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  GET: GET$9,
  PATCH: PATCH$4
}, Symbol.toStringTag, { value: 'Module' }));

async function GET$8() {
  try {
    const [tradersStats, stallsStats, billsStats, porterStats, revenueStats, auditRecent] = await sql.transaction([
    // Trader counts
    sql`SELECT
        COUNT(*) as total,
        COUNT(*) FILTER (WHERE status = 'active') as active,
        COUNT(*) FILTER (WHERE status = 'warning') as warning,
        COUNT(*) FILTER (WHERE status = 'inactive') as inactive
      FROM traders`,
    // Stall occupancy
    sql`SELECT
        COUNT(*) as total,
        COUNT(*) FILTER (WHERE status = 'occupied') as occupied,
        COUNT(*) FILTER (WHERE status = 'vacant') as vacant,
        COUNT(*) FILTER (WHERE zone = 'gold') as gold_count,
        COUNT(*) FILTER (WHERE zone = 'silver') as silver_count,
        COUNT(*) FILTER (WHERE zone = 'bronze') as bronze_count
      FROM stalls`,
    // Billing stats this month
    sql`SELECT
        COUNT(*) as total_bills,
        COUNT(*) FILTER (WHERE status = 'paid') as paid_count,
        COUNT(*) FILTER (WHERE status = 'unpaid') as unpaid_count,
        COALESCE(SUM(amount) FILTER (WHERE status = 'paid'), 0) as total_collected,
        COALESCE(SUM(amount), 0) as total_billed
      FROM bills
      WHERE bill_month = TO_CHAR(CURRENT_DATE, 'YYYY-MM')`,
    // Porter stats
    sql`SELECT
        COUNT(*) as total,
        COUNT(*) FILTER (WHERE status = 'available') as available,
        COUNT(*) FILTER (WHERE status = 'active') as on_duty,
        ROUND(AVG(rating)::numeric, 2) as avg_rating
      FROM porters`,
    // Revenue last 6 months
    sql`SELECT
        bill_month,
        COALESCE(SUM(amount) FILTER (WHERE status = 'paid'), 0) as collected,
        COALESCE(SUM(amount), 0) as billed
      FROM bills
      GROUP BY bill_month
      ORDER BY bill_month DESC
      LIMIT 6`,
    // Recent activity
    sql`SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 8`]);
    const traders = tradersStats[0];
    const stalls = stallsStats[0];
    const billing = billsStats[0];
    const porters = porterStats[0];
    const occupancyRate = stalls.total > 0 ? Math.round(Number(stalls.occupied) / Number(stalls.total) * 100) : 0;
    const complianceRate = billing.total_bills > 0 ? Math.round(Number(billing.paid_count) / Number(billing.total_bills) * 100) : 0;

    // Permit stats
    const permitStats = await sql`
      SELECT
        COUNT(*) as total,
        COUNT(*) FILTER (WHERE status = 'active') as active,
        COUNT(*) FILTER (WHERE status = 'expired') as expired,
        COUNT(*) FILTER (WHERE status = 'active' AND expiry_date <= CURRENT_DATE + INTERVAL '30 days') as expiring_soon
      FROM permits
    `;
    return Response.json({
      traders: {
        total: Number(traders.total),
        active: Number(traders.active),
        warning: Number(traders.warning),
        inactive: Number(traders.inactive)
      },
      stalls: {
        total: Number(stalls.total),
        occupied: Number(stalls.occupied),
        vacant: Number(stalls.vacant),
        occupancyRate,
        gold: Number(stalls.gold_count),
        silver: Number(stalls.silver_count),
        bronze: Number(stalls.bronze_count)
      },
      billing: {
        totalBills: Number(billing.total_bills),
        paid: Number(billing.paid_count),
        unpaid: Number(billing.unpaid_count),
        totalCollected: Number(billing.total_collected),
        totalBilled: Number(billing.total_billed),
        complianceRate
      },
      porters: {
        total: Number(porters.total),
        available: Number(porters.available),
        onDuty: Number(porters.on_duty),
        avgRating: Number(porters.avg_rating || 5)
      },
      permits: {
        total: Number(permitStats[0].total),
        active: Number(permitStats[0].active),
        expired: Number(permitStats[0].expired),
        expiringSoon: Number(permitStats[0].expiring_soon)
      },
      revenue: revenueStats.map(r => ({
        month: r.bill_month,
        collected: Number(r.collected),
        billed: Number(r.billed)
      })),
      recentActivity: auditRecent
    });
  } catch (error) {
    console.error(error);
    return Response.json({
      error: "Failed to fetch stats"
    }, {
      status: 500
    });
  }
}

const __vite_glob_0_7 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  GET: GET$8
}, Symbol.toStringTag, { value: 'Module' }));

async function GET$7(request) {
  try {
    const {
      searchParams
    } = new URL(request.url);
    const search = searchParams.get("search") || "";
    const status = searchParams.get("status") || "";
    let query = `
      SELECT t.*, s.stall_code, s.zone, s.category,
             p.permit_number, p.status as permit_status, p.expiry_date
      FROM traders t
      LEFT JOIN stalls s ON t.stall_id = s.id
      LEFT JOIN permits p ON p.trader_id = t.id
      WHERE 1=1
    `;
    const values = [];
    let idx = 1;
    if (search) {
      query += ` AND (LOWER(t.name) LIKE LOWER($${idx}) OR t.nik LIKE $${idx + 1} OR t.phone LIKE $${idx + 2})`;
      values.push(`%${search}%`, `%${search}%`, `%${search}%`);
      idx += 3;
    }
    if (status) {
      query += ` AND t.status = $${idx}`;
      values.push(status);
      idx++;
    }
    query += ` ORDER BY t.joined_at DESC`;
    const rows = await sql(query, values);
    return Response.json(rows);
  } catch (error) {
    console.error(error);
    return Response.json({
      error: "Failed to fetch traders"
    }, {
      status: 500
    });
  }
}
async function POST$5(request) {
  try {
    const body = await request.json();
    const {
      name,
      nik,
      phone,
      trader_type,
      stall_id
    } = body;
    const trader = await sql`
      INSERT INTO traders (name, nik, phone, trader_type, stall_id)
      VALUES (${name}, ${nik}, ${phone}, ${trader_type || "tetap"}, ${stall_id || null})
      RETURNING *
    `;

    // Assign stall if provided
    if (stall_id) {
      await sql`UPDATE stalls SET status = 'occupied', trader_id = ${trader[0].id} WHERE id = ${stall_id}`;
    }

    // Auto-generate SIPTU
    const permitNum = `SIPTU-${new Date().getFullYear()}-${String(trader[0].id).padStart(4, "0")}`;
    const issueDate = new Date().toISOString().split("T")[0];
    const expiryDate = new Date(new Date().setFullYear(new Date().getFullYear() + 1)).toISOString().split("T")[0];
    await sql`
      INSERT INTO permits (trader_id, permit_number, issue_date, expiry_date, status, qr_token)
      VALUES (${trader[0].id}, ${permitNum}, ${issueDate}, ${expiryDate}, 'active', ${Math.random().toString(36).slice(2)})
      ON CONFLICT (permit_number) DO NOTHING
    `;
    await sql`
      INSERT INTO audit_logs (module, action, description)
      VALUES ('Pedagang', 'CREATE', ${`Pedagang baru terdaftar: ${name}`})
    `;
    return Response.json(trader[0]);
  } catch (error) {
    console.error(error);
    return Response.json({
      error: "Failed to create trader"
    }, {
      status: 500
    });
  }
}
async function PATCH$3(request) {
  try {
    const body = await request.json();
    const {
      id,
      status,
      name,
      phone,
      stall_id
    } = body;
    const updated = await sql`
      UPDATE traders SET
        status = COALESCE(${status}, status),
        name = COALESCE(${name}, name),
        phone = COALESCE(${phone}, phone),
        stall_id = COALESCE(${stall_id}, stall_id)
      WHERE id = ${id}
      RETURNING *
    `;
    await sql`
      INSERT INTO audit_logs (module, action, description)
      VALUES ('Pedagang', 'UPDATE', ${`Data pedagang #${id} diperbarui`})
    `;
    return Response.json(updated[0]);
  } catch (error) {
    console.error(error);
    return Response.json({
      error: "Failed to update trader"
    }, {
      status: 500
    });
  }
}
async function DELETE(request) {
  try {
    const {
      searchParams
    } = new URL(request.url);
    const id = searchParams.get("id");
    const trader = await sql`SELECT name FROM traders WHERE id = ${id}`;
    await sql`UPDATE stalls SET status = 'vacant', trader_id = NULL WHERE trader_id = ${id}`;
    await sql`UPDATE traders SET status = 'inactive' WHERE id = ${id}`;
    await sql`
      INSERT INTO audit_logs (module, action, description)
      VALUES ('Pedagang', 'DELETE', ${`Pedagang ${trader[0]?.name} dinonaktifkan`})
    `;
    return Response.json({
      success: true
    });
  } catch (error) {
    console.error(error);
    return Response.json({
      error: "Failed to delete trader"
    }, {
      status: 500
    });
  }
}

const __vite_glob_0_8 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  DELETE,
  GET: GET$7,
  PATCH: PATCH$3,
  POST: POST$5
}, Symbol.toStringTag, { value: 'Module' }));

// Supported message templates
const templates = {
  billing_reminder: data => `Yth. *${data.trader_name}*,\n\nTagihan sewa lapak *${data.stall_code}* untuk bulan *${data.bill_month}* sebesar *Rp ${Number(data.amount).toLocaleString("id-ID")}* belum terbayar.\n\nMohon segera melakukan pembayaran ke kantor manajemen pasar.\n\nTerima kasih 🙏\n_Manajemen Pasar Modern_`,
  siptu_expiry: data => `Yth. *${data.trader_name}*,\n\nSIPTU Anda nomor *${data.permit_number}* akan kadaluarsa pada *${data.expiry_date}*.\n\nSilakan perpanjang SIPTU Anda di kantor manajemen sebelum tanggal tersebut.\n\nTerima kasih 🙏\n_Manajemen Pasar Modern_`,
  porter_incentive: data => `Yth. *${data.porter_name}*,\n\nSelamat! Insentif minggu ini Anda telah disetujui.\n\n🏅 Tier: *${data.tier}*\n💰 Bonus: *Rp ${Number(data.bonus).toLocaleString("id-ID")}*\n⭐ Rating: ${data.rating}\n📦 Job selesai: ${data.jobs} job\n\nBonus akan dibayarkan segera. Terima kasih atas kerja kerasnya!\n_Manajemen Pasar Modern_`,
  general: data => data.message
};

// Send via Fonnte (WA API populer Indonesia)
async function sendWhatsApp(phone, message) {
  const apiKey = process.env.WHATSAPP_API_KEY;
  if (!apiKey) {
    // Simulate success in dev if no key set
    console.log(`[WA QUEUE] To: ${phone} | Msg: ${message.slice(0, 60)}...`);
    return {
      status: "queued_dev",
      phone
    };
  }

  // Normalize phone number
  let normalized = phone.replace(/\D/g, "");
  if (normalized.startsWith("0")) normalized = "62" + normalized.slice(1);
  if (!normalized.startsWith("62")) normalized = "62" + normalized;
  const res = await fetch("https://api.fonnte.com/send", {
    method: "POST",
    headers: {
      Authorization: apiKey,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      target: normalized,
      message,
      countryCode: "62"
    })
  });
  const result = await res.json();
  return result;
}

// GET: get queue history
async function GET$6(request) {
  try {
    const {
      searchParams
    } = new URL(request.url);
    const type = searchParams.get("type") || "";
    let query = `SELECT * FROM audit_logs WHERE module = 'WhatsApp'`;
    const values = [];
    if (type) {
      query += ` AND action = $1`;
      values.push(type);
    }
    query += ` ORDER BY created_at DESC LIMIT 50`;
    const rows = await sql(query, values);
    return Response.json(rows);
  } catch (error) {
    console.error(error);
    return Response.json({
      error: "Failed to fetch WA queue"
    }, {
      status: 500
    });
  }
}

// POST: send notification(s)
async function POST$4(request) {
  try {
    const body = await request.json();
    const {
      type,
      targets
    } = body;
    // targets: array of { phone, ...templateData }
    // type: billing_reminder | siptu_expiry | porter_incentive | general

    if (!type || !targets || !targets.length) {
      return Response.json({
        error: "type and targets[] required"
      }, {
        status: 400
      });
    }
    const results = [];
    for (const target of targets) {
      const templateFn = templates[type] || templates.general;
      const message = templateFn(target);
      try {
        const result = await sendWhatsApp(target.phone, message);
        results.push({
          phone: target.phone,
          name: target.trader_name || target.porter_name,
          status: "sent",
          result
        });
        await sql`
          INSERT INTO audit_logs (module, action, user_name, description)
          VALUES ('WhatsApp', ${type}, 'Sistem', ${`Notifikasi ${type} dikirim ke ${target.trader_name || target.porter_name} (${target.phone})`})
        `;
      } catch (e) {
        results.push({
          phone: target.phone,
          status: "failed",
          error: e.message
        });
      }
    }
    return Response.json({
      sent: results.filter(r => r.status === "sent").length,
      failed: results.filter(r => r.status === "failed").length,
      results
    });
  } catch (error) {
    console.error(error);
    return Response.json({
      error: "Failed to send WhatsApp"
    }, {
      status: 500
    });
  }
}

const __vite_glob_0_9 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  GET: GET$6,
  POST: POST$4
}, Symbol.toStringTag, { value: 'Module' }));

async function GET$5(request) {
  const isSecure = process.env.AUTH_URL?.startsWith('https') ?? request.url?.startsWith('https') ?? false;
  const [token, jwt] = await Promise.all([getToken({
    req: request,
    secret: process.env.AUTH_SECRET,
    secureCookie: isSecure,
    raw: true
  }), getToken({
    req: request,
    secret: process.env.AUTH_SECRET,
    secureCookie: isSecure
  })]);
  if (!jwt) {
    return new Response(`
			<html>
				<body>
					<script>
						window.parent.postMessage({ type: 'AUTH_ERROR', error: 'Unauthorized' }, '*');
					</script>
				</body>
			</html>
			`, {
      status: 401,
      headers: {
        'Content-Type': 'text/html'
      }
    });
  }
  const message = {
    type: 'AUTH_SUCCESS',
    jwt: token,
    user: {
      id: jwt.sub,
      email: jwt.email,
      name: jwt.name
    }
  };
  return new Response(`
		<html>
			<body>
				<script>
					window.parent.postMessage(${JSON.stringify(message)}, '*');
				</script>
			</body>
		</html>
		`, {
    headers: {
      'Content-Type': 'text/html'
    }
  });
}

const __vite_glob_0_10 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  GET: GET$5
}, Symbol.toStringTag, { value: 'Module' }));

async function GET$4(request) {
  const isSecure = process.env.AUTH_URL?.startsWith('https') ?? request.url?.startsWith('https') ?? false;
  const [token, jwt] = await Promise.all([getToken({
    req: request,
    secret: process.env.AUTH_SECRET,
    secureCookie: isSecure,
    raw: true
  }), getToken({
    req: request,
    secret: process.env.AUTH_SECRET,
    secureCookie: isSecure
  })]);
  if (!jwt) {
    return new Response(JSON.stringify({
      error: 'Unauthorized'
    }), {
      status: 401,
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
  return new Response(JSON.stringify({
    jwt: token,
    user: {
      id: jwt.sub,
      email: jwt.email,
      name: jwt.name
    }
  }), {
    headers: {
      'Content-Type': 'application/json'
    }
  });
}

const __vite_glob_0_11 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  GET: GET$4
}, Symbol.toStringTag, { value: 'Module' }));

// Incentive tier calculation logic
function calculateTier(jobsCompleted, avgRating, daysHitTarget) {
  const score = (jobsCompleted >= 50 ? 3 : jobsCompleted >= 30 ? 2 : jobsCompleted >= 15 ? 1 : 0) + (avgRating >= 4.8 ? 3 : avgRating >= 4.5 ? 2 : avgRating >= 4.0 ? 1 : 0) + (daysHitTarget >= 6 ? 3 : daysHitTarget >= 4 ? 2 : daysHitTarget >= 2 ? 1 : 0);
  if (score >= 8) return {
    tier: "platinum",
    bonus: 150000,
    label: "Platinum"
  };
  if (score >= 6) return {
    tier: "gold",
    bonus: 100000,
    label: "Gold"
  };
  if (score >= 4) return {
    tier: "silver",
    bonus: 60000,
    label: "Silver"
  };
  if (score >= 2) return {
    tier: "bronze",
    bonus: 30000,
    label: "Bronze"
  };
  return {
    tier: "none",
    bonus: 0,
    label: "Belum Memenuhi"
  };
}

// GET: fetch incentives for a porter or all incentives
async function GET$3(request) {
  try {
    const {
      searchParams
    } = new URL(request.url);
    const porterId = searchParams.get("porterId");
    const recalculate = searchParams.get("recalculate");
    if (recalculate === "true" && porterId) {
      // Calculate weekly stats for this porter
      const weekStart = new Date();
      weekStart.setDate(weekStart.getDate() - weekStart.getDay() + 1); // Monday
      weekStart.setHours(0, 0, 0, 0);
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekEnd.getDate() + 6);
      weekEnd.setHours(23, 59, 59, 999);
      const weekStartStr = weekStart.toISOString().split("T")[0];
      const weekEndStr = weekEnd.toISOString().split("T")[0];
      const stats = await sql`
        SELECT 
          COUNT(*) FILTER (WHERE status = 'completed') as jobs_completed,
          ROUND(AVG(rating) FILTER (WHERE rating IS NOT NULL)::numeric, 2) as avg_rating,
          COALESCE(SUM(fee) FILTER (WHERE status = 'completed'), 0) as total_earnings
        FROM porter_jobs
        WHERE porter_id = ${porterId}
          AND created_at >= ${weekStartStr}::date
          AND created_at <= (${weekEndStr}::date + INTERVAL '1 day')
      `;
      const porterInfo = await sql`SELECT daily_target FROM porters WHERE id = ${porterId}`;
      const dailyTarget = porterInfo[0]?.daily_target || 100000;

      // Count days where porter hit their daily target
      const dailyEarnings = await sql`
        SELECT DATE(created_at) as day, SUM(fee) as day_total
        FROM porter_jobs
        WHERE porter_id = ${porterId}
          AND status = 'completed'
          AND created_at >= ${weekStartStr}::date
          AND created_at <= (${weekEndStr}::date + INTERVAL '1 day')
        GROUP BY DATE(created_at)
      `;
      const daysHitTarget = dailyEarnings.filter(d => Number(d.day_total) >= dailyTarget).length;
      const jobsCompleted = Number(stats[0]?.jobs_completed || 0);
      const avgRating = Number(stats[0]?.avg_rating || 0);
      const totalEarnings = Number(stats[0]?.total_earnings || 0);
      const {
        tier,
        bonus,
        label
      } = calculateTier(jobsCompleted, avgRating, daysHitTarget);
      return Response.json({
        porterId: Number(porterId),
        weekStart: weekStartStr,
        weekEnd: weekEndStr,
        jobsCompleted,
        avgRating,
        totalEarnings,
        daysHitTarget,
        tier,
        bonus,
        tierLabel: label,
        // Progress to next tier info
        progress: {
          jobs: jobsCompleted,
          jobsNextTier: jobsCompleted < 15 ? 15 : jobsCompleted < 30 ? 30 : jobsCompleted < 50 ? 50 : 50,
          rating: avgRating,
          ratingNextTier: avgRating < 4.0 ? 4.0 : avgRating < 4.5 ? 4.5 : avgRating < 4.8 ? 4.8 : 4.8,
          daysHit: daysHitTarget,
          daysNextTier: daysHitTarget < 2 ? 2 : daysHitTarget < 4 ? 4 : daysHitTarget < 6 ? 6 : 6
        }
      });
    }

    // Fetch saved incentive history
    if (porterId) {
      const rows = await sql`
        SELECT pi.*, p.name as porter_name
        FROM porter_incentives pi
        JOIN porters p ON pi.porter_id = p.id
        WHERE pi.porter_id = ${porterId}
        ORDER BY pi.week_start DESC
        LIMIT 12
      `;
      return Response.json(rows);
    }

    // All porters incentive overview (current week)
    const allRows = await sql`
      SELECT pi.*, p.name as porter_name
      FROM porter_incentives pi
      JOIN porters p ON pi.porter_id = p.id
      ORDER BY pi.week_start DESC, pi.bonus_amount DESC
    `;
    return Response.json(allRows);
  } catch (error) {
    console.error(error);
    return Response.json({
      error: "Failed to fetch incentives"
    }, {
      status: 500
    });
  }
}

// POST: save / lock in a weekly incentive record
async function POST$3(request) {
  try {
    const body = await request.json();
    const {
      porter_id,
      week_start,
      week_end,
      jobs_completed,
      avg_rating,
      total_earnings,
      days_hit_target,
      tier,
      bonus_amount
    } = body;
    const existing = await sql`
      SELECT id FROM porter_incentives WHERE porter_id = ${porter_id} AND week_start = ${week_start}
    `;
    if (existing.length > 0) {
      const updated = await sql`
        UPDATE porter_incentives
        SET jobs_completed = ${jobs_completed}, avg_rating = ${avg_rating},
            total_earnings = ${total_earnings}, days_hit_target = ${days_hit_target},
            tier = ${tier}, bonus_amount = ${bonus_amount}, status = 'approved'
        WHERE porter_id = ${porter_id} AND week_start = ${week_start}
        RETURNING *
      `;
      return Response.json(updated[0]);
    }
    const newRecord = await sql`
      INSERT INTO porter_incentives (porter_id, week_start, week_end, jobs_completed, avg_rating, total_earnings, days_hit_target, tier, bonus_amount, status)
      VALUES (${porter_id}, ${week_start}, ${week_end}, ${jobs_completed}, ${avg_rating}, ${total_earnings}, ${days_hit_target}, ${tier}, ${bonus_amount}, 'approved')
      RETURNING *
    `;
    return Response.json(newRecord[0]);
  } catch (error) {
    console.error(error);
    return Response.json({
      error: "Failed to save incentive"
    }, {
      status: 500
    });
  }
}

// PATCH: mark incentive as paid
async function PATCH$2(request) {
  try {
    const body = await request.json();
    const {
      id
    } = body;
    const updated = await sql`
      UPDATE porter_incentives
      SET status = 'paid', paid_at = NOW()
      WHERE id = ${id}
      RETURNING *
    `;
    return Response.json(updated[0]);
  } catch (error) {
    console.error(error);
    return Response.json({
      error: "Failed to mark as paid"
    }, {
      status: 500
    });
  }
}

const __vite_glob_0_12 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  GET: GET$3,
  PATCH: PATCH$2,
  POST: POST$3
}, Symbol.toStringTag, { value: 'Module' }));

async function GET$2(request) {
  try {
    const {
      searchParams
    } = new URL(request.url);
    const porterId = searchParams.get("porterId");
    if (porterId) {
      const jobs = await sql`
        SELECT * FROM porter_jobs 
        WHERE porter_id = ${porterId} 
        ORDER BY created_at DESC
      `;
      return Response.json(jobs);
    }
    const allJobs = await sql`SELECT * FROM porter_jobs ORDER BY created_at DESC`;
    return Response.json(allJobs);
  } catch (error) {
    console.error(error);
    return Response.json({
      error: "Failed to fetch jobs"
    }, {
      status: 500
    });
  }
}
async function POST$2(request) {
  try {
    const body = await request.json();
    const {
      porter_id,
      customer_name,
      location_from,
      location_to,
      weight_category,
      fee
    } = body;
    const newJob = await sql`
      INSERT INTO porter_jobs (porter_id, customer_name, location_from, location_to, weight_category, fee, status)
      VALUES (${porter_id}, ${customer_name}, ${location_from}, ${location_to}, ${weight_category}, ${fee}, 'pending')
      RETURNING *
    `;

    // Also update porter status to active if a porter is assigned immediately
    if (porter_id) {
      await sql`UPDATE porters SET status = 'active' WHERE id = ${porter_id}`;
    }
    return Response.json(newJob[0]);
  } catch (error) {
    console.error(error);
    return Response.json({
      error: "Failed to create job"
    }, {
      status: 500
    });
  }
}
async function PATCH$1(request) {
  try {
    const body = await request.json();
    const {
      id,
      status
    } = body;
    const updatedJob = await sql`
      UPDATE porter_jobs 
      SET status = ${status}, 
          completed_at = ${status === "completed" ? "NOW()" : null}
      WHERE id = ${id} 
      RETURNING *
    `;

    // If job is completed or cancelled, make porter available again
    if (status === "completed" || status === "cancelled") {
      const job = updatedJob[0];
      await sql`UPDATE porters SET status = 'available' WHERE id = ${job.porter_id}`;
    }
    return Response.json(updatedJob[0]);
  } catch (error) {
    console.error(error);
    return Response.json({
      error: "Failed to update job"
    }, {
      status: 500
    });
  }
}

const __vite_glob_0_13 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  GET: GET$2,
  PATCH: PATCH$1,
  POST: POST$2
}, Symbol.toStringTag, { value: 'Module' }));

async function GET$1(request) {
  try {
    const {
      searchParams
    } = new URL(request.url);
    const id = searchParams.get("id");
    if (id) {
      const porter = await sql`
        SELECT p.*, 
        (SELECT COALESCE(SUM(fee), 0) FROM porter_jobs WHERE porter_id = p.id AND status = 'completed' AND created_at >= CURRENT_DATE) as daily_earnings
        FROM porters p 
        WHERE p.id = ${id}
      `;
      return Response.json(porter[0]);
    }
    const porters = await sql`SELECT * FROM porters ORDER BY name ASC`;
    return Response.json(porters);
  } catch (error) {
    console.error(error);
    return Response.json({
      error: "Failed to fetch porters"
    }, {
      status: 500
    });
  }
}
async function PATCH(request) {
  try {
    const body = await request.json();
    const {
      id,
      status
    } = body;
    if (!id || !status) {
      return Response.json({
        error: "ID and status are required"
      }, {
        status: 400
      });
    }
    const updated = await sql`
      UPDATE porters 
      SET status = ${status} 
      WHERE id = ${id} 
      RETURNING *
    `;
    return Response.json(updated[0]);
  } catch (error) {
    console.error(error);
    return Response.json({
      error: "Failed to update porter status"
    }, {
      status: 500
    });
  }
}
async function POST$1(request) {
  try {
    const body = await request.json();
    const {
      name,
      phone,
      id_number,
      daily_target
    } = body;
    if (!name || !phone || !id_number) {
      return Response.json({
        error: "name, phone, dan id_number wajib diisi"
      }, {
        status: 400
      });
    }
    const newPorter = await sql`
      INSERT INTO porters (name, phone, id_number, daily_target, status, rating)
      VALUES (${name}, ${phone}, ${id_number}, ${daily_target || 100000}, 'available', 5.00)
      RETURNING *
    `;
    return Response.json(newPorter[0]);
  } catch (error) {
    console.error(error);
    if (error.message?.includes("unique")) {
      return Response.json({
        error: "Nomor HP atau ID sudah terdaftar"
      }, {
        status: 409
      });
    }
    return Response.json({
      error: "Failed to create porter"
    }, {
      status: 500
    });
  }
}

const __vite_glob_0_14 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  GET: GET$1,
  PATCH,
  POST: POST$1
}, Symbol.toStringTag, { value: 'Module' }));

// GET: fetch ratings for a porter
async function GET(request) {
  try {
    const {
      searchParams
    } = new URL(request.url);
    const porterId = searchParams.get("porterId");
    const jobId = searchParams.get("jobId");
    if (jobId) {
      const rows = await sql`
        SELECT pj.id, pj.rating, pj.feedback, pj.rated_at, pj.customer_name, pj.location_to, pj.fee, pj.completed_at
        FROM porter_jobs pj
        WHERE pj.id = ${jobId}
      `;
      return Response.json(rows[0] || null);
    }
    if (porterId) {
      const rows = await sql`
        SELECT pj.id, pj.rating, pj.feedback, pj.rated_at, pj.customer_name, pj.location_to, pj.fee, pj.completed_at
        FROM porter_jobs pj
        WHERE pj.porter_id = ${porterId} AND pj.rating IS NOT NULL
        ORDER BY pj.rated_at DESC
        LIMIT 20
      `;
      return Response.json(rows);
    }
    return Response.json({
      error: "porterId or jobId required"
    }, {
      status: 400
    });
  } catch (error) {
    console.error(error);
    return Response.json({
      error: "Failed to fetch ratings"
    }, {
      status: 500
    });
  }
}

// POST: submit a rating for a completed job
async function POST(request) {
  try {
    const body = await request.json();
    const {
      job_id,
      rating,
      feedback
    } = body;
    if (!job_id || !rating || rating < 1 || rating > 5) {
      return Response.json({
        error: "job_id and rating (1-5) required"
      }, {
        status: 400
      });
    }

    // Update job with rating
    const updatedJob = await sql`
      UPDATE porter_jobs
      SET rating = ${rating}, feedback = ${feedback || null}, rated_at = NOW()
      WHERE id = ${job_id} AND status = 'completed'
      RETURNING *
    `;
    if (!updatedJob[0]) {
      return Response.json({
        error: "Job not found or not completed"
      }, {
        status: 404
      });
    }

    // Recalculate porter avg rating
    const porterId = updatedJob[0].porter_id;
    const avgResult = await sql`
      SELECT ROUND(AVG(rating)::numeric, 2) as avg_rating
      FROM porter_jobs
      WHERE porter_id = ${porterId} AND rating IS NOT NULL
    `;
    const newAvg = avgResult[0]?.avg_rating || 5.0;
    await sql`UPDATE porters SET rating = ${newAvg} WHERE id = ${porterId}`;
    return Response.json({
      success: true,
      job: updatedJob[0],
      new_avg_rating: newAvg
    });
  } catch (error) {
    console.error(error);
    return Response.json({
      error: "Failed to submit rating"
    }, {
      status: 500
    });
  }
}

const __vite_glob_0_15 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  GET,
  POST
}, Symbol.toStringTag, { value: 'Module' }));

const originalFetch = fetch;
const isBackend = () => typeof window === "undefined";
const safeStringify = (value) => JSON.stringify(value, (_k, v) => {
  if (v instanceof Date) return { __t: "Date", v: v.toISOString() };
  if (v instanceof Error)
    return { __t: "Error", v: { name: v.name, message: v.message, stack: v.stack } };
  return v;
});
const postToParent = (level, text, extra) => {
  try {
    if (isBackend() || !window.parent || window.parent === window) {
      ("level" in console ? console[level] : console.log)(text, extra);
      return;
    }
    window.parent.postMessage(
      {
        type: "sandbox:web:console-write",
        __viteConsole: true,
        level,
        text,
        args: [safeStringify(extra)]
      },
      "*"
    );
  } catch {
  }
};
const getUrlFromArgs = (...args) => {
  const [input] = args;
  if (typeof input === "string") return input;
  if (input instanceof Request) return input.url;
  return `${input.protocol}//${input.host}${input.pathname}`;
};
const isFirstPartyURL = (url) => {
  return url.startsWith("/integrations") || url.startsWith("/_create");
};
const isSecondPartyUrl = (url) => {
  return process.env.NEXT_PUBLIC_CREATE_API_BASE_URL && url.startsWith(process.env.NEXT_PUBLIC_CREATE_API_BASE_URL) || process.env.NEXT_PUBLIC_CREATE_BASE_URL && url.startsWith(process.env.NEXT_PUBLIC_CREATE_BASE_URL) || url.startsWith("https://www.create.xyz") || url.startsWith("https://api.create.xyz/") || url.startsWith("https://www.createanything.com") || url.startsWith("https://api.createanything.com");
};
const fetchWithHeaders = async (input, init) => {
  const url = getUrlFromArgs(input, init);
  const additionalHeaders = {
    "x-createxyz-project-group-id": process.env.NEXT_PUBLIC_PROJECT_GROUP_ID
  };
  const isExternalFetch = !isFirstPartyURL(url) && !isSecondPartyUrl(url);
  if (isExternalFetch || url.startsWith("/api")) {
    return originalFetch(input, init);
  }
  let finalInit;
  if (input instanceof Request) {
    const hasBody = !!input.body;
    finalInit = {
      method: input.method,
      headers: new Headers(input.headers),
      body: input.body,
      mode: input.mode,
      credentials: input.credentials,
      cache: input.cache,
      redirect: input.redirect,
      referrer: input.referrer,
      referrerPolicy: input.referrerPolicy,
      integrity: input.integrity,
      keepalive: input.keepalive,
      signal: input.signal,
      ...hasBody ? { duplex: "half" } : {},
      ...init
    };
  } else {
    finalInit = { ...init, headers: new Headers(init?.headers ?? {}) };
  }
  const finalHeaders = new Headers(finalInit.headers);
  for (const [key, value] of Object.entries(additionalHeaders)) {
    if (value) finalHeaders.set(key, value);
  }
  finalInit.headers = finalHeaders;
  const prefix = !isSecondPartyUrl(url) ? isBackend() ? process.env.NEXT_PUBLIC_CREATE_BASE_URL ?? "https://www.create.xyz" : "" : "";
  try {
    const result = await originalFetch(`${prefix}${url}`, finalInit);
    if (!result.ok) {
      postToParent(
        "error",
        `Failed to load resource: the server responded with a status of ${result.status} (${result.statusText ?? ""})`,
        {
          url,
          status: result.status,
          statusText: result.statusText
        }
      );
    }
    return result;
  } catch (error) {
    postToParent("error", "Fetch error", {
      url,
      error: error instanceof Error ? { name: error.name, message: error.message, stack: error.stack } : error
    });
    throw error;
  }
};

const API_BASENAME = "/api";
const api = new Hono();
if (globalThis.fetch) {
  globalThis.fetch = fetchWithHeaders;
}
function getHonoPath(routeFile) {
  const relativePath = routeFile.replace("../src/app/api/", "");
  const parts = relativePath.split("/").filter(Boolean);
  const routeParts = parts.slice(0, -1);
  if (routeParts.length === 0) {
    return [{ name: "root", pattern: "" }];
  }
  const transformedParts = routeParts.map((segment) => {
    const match = segment.match(/^\[(\.{3})?([^\]]+)\]$/);
    if (match) {
      const [_, dots, param] = match;
      return dots === "..." ? { name: param, pattern: `:${param}{.+}` } : { name: param, pattern: `:${param}` };
    }
    return { name: segment, pattern: segment };
  });
  return transformedParts;
}
const routeModules = /* #__PURE__ */ Object.assign({"../src/app/api/__create/check-social-secrets/route.js": __vite_glob_0_0,"../src/app/api/__create/ssr-test/route.js": __vite_glob_0_1,"../src/app/api/admin/audit/route.js": __vite_glob_0_2,"../src/app/api/admin/bills/route.js": __vite_glob_0_3,"../src/app/api/admin/permits/route.js": __vite_glob_0_4,"../src/app/api/admin/reports/route.js": __vite_glob_0_5,"../src/app/api/admin/stalls/route.js": __vite_glob_0_6,"../src/app/api/admin/stats/route.js": __vite_glob_0_7,"../src/app/api/admin/traders/route.js": __vite_glob_0_8,"../src/app/api/admin/whatsapp/route.js": __vite_glob_0_9,"../src/app/api/auth/expo-web-success/route.js": __vite_glob_0_10,"../src/app/api/auth/token/route.js": __vite_glob_0_11,"../src/app/api/incentives/route.js": __vite_glob_0_12,"../src/app/api/jobs/route.js": __vite_glob_0_13,"../src/app/api/porters/route.js": __vite_glob_0_14,"../src/app/api/ratings/route.js": __vite_glob_0_15});
async function registerRoutes() {
  api.routes = [];
  const routeFiles = Object.keys(routeModules).sort((a, b) => b.length - a.length);
  for (const routeFile of routeFiles) {
    try {
      const route = routeModules[routeFile];
      const methods = ["GET", "POST", "PUT", "DELETE", "PATCH"];
      for (const method of methods) {
        try {
          if (route[method]) {
            const parts = getHonoPath(routeFile);
            const honoPath = `/${parts.map(({ pattern }) => pattern).join("/")}`;
            const handler = async (c) => {
              const params = c.req.param();
              return await route[method](c.req.raw, { params });
            };
            const methodLowercase = method.toLowerCase();
            switch (methodLowercase) {
              case "get":
                api.get(honoPath, handler);
                break;
              case "post":
                api.post(honoPath, handler);
                break;
              case "put":
                api.put(honoPath, handler);
                break;
              case "delete":
                api.delete(honoPath, handler);
                break;
              case "patch":
                api.patch(honoPath, handler);
                break;
              default:
                console.warn(`Unsupported method: ${method}`);
                break;
            }
          }
        } catch (error) {
          console.error(`Error registering route ${routeFile} for method ${method}:`, error);
        }
      }
    } catch (error) {
      console.error(`Error processing route file ${routeFile}:`, error);
    }
  }
}
await registerRoutes();

neonConfig.webSocketConstructor = ws;
const als = new AsyncLocalStorage();
for (const method of ["log", "info", "warn", "error", "debug"]) {
  const original = nodeConsole[method].bind(console);
  console[method] = (...args) => {
    const requestId2 = als.getStore()?.requestId;
    if (requestId2) {
      original(`[traceId:${requestId2}]`, ...args);
    } else {
      original(...args);
    }
  };
}
const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});
const adapter = NeonAdapter(pool);
const app = new Hono();
app.use("*", requestId());
app.use("*", (c, next) => {
  const requestId2 = c.get("requestId");
  return als.run({ requestId: requestId2 }, () => next());
});
app.use(contextStorage());
app.onError((err, c) => {
  if (c.req.method !== "GET") {
    return c.json(
      {
        error: "An error occurred in your app",
        details: serializeError(err)
      },
      500
    );
  }
  return c.html(getHTMLForErrorPage(err), 200);
});
if (process.env.CORS_ORIGINS) {
  app.use(
    "/*",
    cors({
      origin: process.env.CORS_ORIGINS.split(",").map((origin) => origin.trim())
    })
  );
}
for (const method of ["post", "put", "patch"]) {
  app[method](
    "*",
    bodyLimit({
      maxSize: 4.5 * 1024 * 1024,
      // 4.5mb to match vercel limit
      onError: (c) => {
        return c.json({ error: "Body size limit exceeded" }, 413);
      }
    })
  );
}
if (process.env.AUTH_SECRET) {
  app.use(
    "*",
    initAuthConfig((c) => ({
      secret: c.env.AUTH_SECRET,
      pages: {
        signIn: "/account/signin",
        signOut: "/account/logout"
      },
      skipCSRFCheck,
      session: {
        strategy: "jwt"
      },
      callbacks: {
        session({ session, token }) {
          if (token.sub) {
            session.user.id = token.sub;
          }
          return session;
        }
      },
      cookies: {
        csrfToken: {
          options: {
            secure: true,
            sameSite: "none"
          }
        },
        sessionToken: {
          options: {
            secure: true,
            sameSite: "none"
          }
        },
        callbackUrl: {
          options: {
            secure: true,
            sameSite: "none"
          }
        }
      },
      providers: [
        // Dev-only provider for simulated social sign-in (Google, Facebook, etc.)
        // Creates or finds a user by email without requiring a password.
        ...process.env.NEXT_PUBLIC_CREATE_ENV === "DEVELOPMENT" ? [
          Credentials({
            id: "dev-social",
            name: "Development Social Sign-in",
            credentials: {
              email: { label: "Email", type: "email" },
              name: { label: "Name", type: "text" },
              provider: { label: "Provider", type: "text" }
            },
            authorize: async (credentials) => {
              const { email, name, provider } = credentials;
              if (!email || typeof email !== "string") return null;
              const existing = await adapter.getUserByEmail(email);
              if (existing) return existing;
              const allowedProviders = /* @__PURE__ */ new Set(["google", "facebook", "twitter", "apple"]);
              const providerName = typeof provider === "string" && allowedProviders.has(provider.toLowerCase()) ? provider.toLowerCase() : "google";
              const newUser = await adapter.createUser({
                emailVerified: null,
                email,
                name: typeof name === "string" && name.length > 0 ? name : void 0
              });
              await adapter.linkAccount({
                type: "oauth",
                userId: newUser.id,
                provider: providerName,
                providerAccountId: `dev-${newUser.id}`
              });
              return newUser;
            }
          })
        ] : [],
        Credentials({
          id: "credentials-signin",
          name: "Credentials Sign in",
          credentials: {
            email: {
              label: "Email",
              type: "email"
            },
            password: {
              label: "Password",
              type: "password"
            }
          },
          authorize: async (credentials) => {
            const { email, password } = credentials;
            if (!email || !password) {
              return null;
            }
            if (typeof email !== "string" || typeof password !== "string") {
              return null;
            }
            const user = await adapter.getUserByEmail(email);
            if (!user) {
              return null;
            }
            const matchingAccount = user.accounts.find(
              (account) => account.provider === "credentials"
            );
            const accountPassword = matchingAccount?.password;
            if (!accountPassword) {
              return null;
            }
            const isValid = await verify(accountPassword, password);
            if (!isValid) {
              return null;
            }
            return user;
          }
        }),
        Credentials({
          id: "credentials-signup",
          name: "Credentials Sign up",
          credentials: {
            email: {
              label: "Email",
              type: "email"
            },
            password: {
              label: "Password",
              type: "password"
            },
            name: { label: "Name", type: "text" },
            image: { label: "Image", type: "text", required: false }
          },
          authorize: async (credentials) => {
            const { email, password, name, image } = credentials;
            if (!email || !password) {
              return null;
            }
            if (typeof email !== "string" || typeof password !== "string") {
              return null;
            }
            const user = await adapter.getUserByEmail(email);
            if (!user) {
              const newUser = await adapter.createUser({
                emailVerified: null,
                email,
                name: typeof name === "string" && name.length > 0 ? name : void 0,
                image: typeof image === "string" && image.length > 0 ? image : void 0
              });
              await adapter.linkAccount({
                extraData: {
                  password: await hash(password)
                },
                type: "credentials",
                userId: newUser.id,
                providerAccountId: newUser.id,
                provider: "credentials"
              });
              return newUser;
            }
            return null;
          }
        })
      ]
    }))
  );
}
app.all("/integrations/:path{.+}", async (c, next) => {
  const queryParams = c.req.query();
  const url = `${process.env.NEXT_PUBLIC_CREATE_BASE_URL ?? "https://www.create.xyz"}/integrations/${c.req.param("path")}${Object.keys(queryParams).length > 0 ? `?${new URLSearchParams(queryParams).toString()}` : ""}`;
  return proxy(url, {
    method: c.req.method,
    body: c.req.raw.body ?? null,
    // @ts-expect-error -- duplex is accepted by the runtime even though the
    // type declarations don't include it; required for streaming integrations
    duplex: "half",
    redirect: "manual",
    headers: {
      ...c.req.header(),
      "X-Forwarded-For": process.env.NEXT_PUBLIC_CREATE_HOST,
      "x-createxyz-host": process.env.NEXT_PUBLIC_CREATE_HOST,
      Host: process.env.NEXT_PUBLIC_CREATE_HOST,
      "x-createxyz-project-group-id": process.env.NEXT_PUBLIC_PROJECT_GROUP_ID
    }
  });
});
app.use("/api/auth/*", async (c, next) => {
  if (isAuthAction(c.req.path)) {
    return authHandler()(c, next);
  }
  return next();
});
app.route(API_BASENAME, api);
const index = await createHonoServer({
  app,
  defaultLogger: false
});

export { fetchWithHeaders as f, index as i };

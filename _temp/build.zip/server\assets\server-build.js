import { jsx, Fragment, jsxs } from 'react/jsx-runtime';
import { PassThrough } from 'node:stream';
import { createReadableStreamFromReadable } from '@react-router/node';
import { ServerRouter, UNSAFE_withComponentProps, Outlet, UNSAFE_withErrorBoundaryProps, useNavigate, useLocation, Meta, Links, ScrollRestoration, Scripts, useRouteError, useAsyncError } from 'react-router';
import { isbot } from 'isbot';
import { renderToPipeableStream } from 'react-dom/server';
import { forwardRef, useEffect, createElement, useRef, useState, Component, useCallback } from 'react';
import { useButton } from '@react-aria/button';
import { f as fetchWithHeaders } from './index-D1dJrLOL.js';
import { SessionProvider } from '@hono/auth-js/react';
import { toPng } from 'html-to-image';
import { serializeError } from 'serialize-error';
import { Toaster, toast } from 'sonner';
import { useIdleTimer } from 'react-idle-timer';
import 'node:async_hooks';
import 'node:console';
import '@auth/core';
import '@auth/core/providers/credentials';
import '@hono/auth-js';
import '@neondatabase/serverless';
import 'argon2';
import 'hono';
import 'hono/context-storage';
import 'hono/cors';
import 'hono/proxy';
import 'hono/body-limit';
import 'hono/request-id';
import 'hono/factory';
import '@hono/node-server';
import '@hono/node-server/serve-static';
import 'hono/logger';
import 'ws';
import '@auth/core/jwt';
import 'node:path';
import 'node:fs';
import 'node:url';
import '@react-router/dev/routes';
import 'clean-stack';

const streamTimeout = 5e3;
function handleRequest(request, responseStatusCode, responseHeaders, routerContext, loadContext) {
  if (request.method.toUpperCase() === "HEAD") {
    return new Response(null, {
      status: responseStatusCode,
      headers: responseHeaders
    });
  }
  return new Promise((resolve, reject) => {
    let shellRendered = false;
    let userAgent = request.headers.get("user-agent");
    let readyOption = userAgent && isbot(userAgent) || routerContext.isSpaMode ? "onAllReady" : "onShellReady";
    let timeoutId = setTimeout(
      () => abort(),
      streamTimeout + 1e3
    );
    const { pipe, abort } = renderToPipeableStream(
      /* @__PURE__ */ jsx(ServerRouter, { context: routerContext, url: request.url }),
      {
        [readyOption]() {
          shellRendered = true;
          const body = new PassThrough({
            final(callback) {
              clearTimeout(timeoutId);
              timeoutId = void 0;
              callback();
            }
          });
          const stream = createReadableStreamFromReadable(body);
          responseHeaders.set("Content-Type", "text/html");
          pipe(body);
          resolve(
            new Response(stream, {
              headers: responseHeaders,
              status: responseStatusCode
            })
          );
        },
        onShellError(error) {
          reject(error);
        },
        onError(error) {
          responseStatusCode = 500;
          if (shellRendered) {
            console.error(error);
          }
        }
      }
    );
  });
}

const entryServer = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: handleRequest,
  streamTimeout
}, Symbol.toStringTag, { value: 'Module' }));

const JSX_RENDER_ID_ATTRIBUTE_NAME = "data-render-id";
function buildGridPlaceholder(w, h) {
  const size = Math.max(w, h);
  const svg = `
    <svg width="${size}" height="${size}" viewBox="0 0 895 895" preserveAspectRatio="xMidYMid slice" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect width="895" height="895" fill="#E9E7E7"/>
<g>
<line x1="447.505" y1="-23" x2="447.505" y2="901" stroke="#C0C0C0" stroke-width="1.00975"/>
<line x1="889.335" y1="447.505" x2="5.66443" y2="447.505" stroke="#C0C0C0" stroke-width="1.00975"/>
<line x1="889.335" y1="278.068" x2="5.66443" y2="278.068" stroke="#C0C0C0" stroke-width="1.00975"/>
<line x1="889.335" y1="57.1505" x2="5.66443" y2="57.1504" stroke="#C0C0C0" stroke-width="1.00975"/>
<line x1="61.8051" y1="883.671" x2="61.8051" y2="6.10572e-05" stroke="#C0C0C0" stroke-width="1.00975"/>
<line x1="282.495" y1="907" x2="282.495" y2="-30" stroke="#C0C0C0" stroke-width="1.00975"/>
<line x1="611.495" y1="907" x2="611.495" y2="-30" stroke="#C0C0C0" stroke-width="1.00975"/>
<line x1="832.185" y1="883.671" x2="832.185" y2="6.10572e-05" stroke="#C0C0C0" stroke-width="1.00975"/>
<line x1="889.335" y1="827.53" x2="5.66443" y2="827.53" stroke="#C0C0C0" stroke-width="1.00975"/>
<line x1="889.335" y1="606.613" x2="5.66443" y2="606.612" stroke="#C0C0C0" stroke-width="1.00975"/>
<line x1="4.3568" y1="4.6428" x2="889.357" y2="888.643" stroke="#C0C0C0" stroke-width="1.00975"/>
<line x1="-0.3568" y1="894.643" x2="894.643" y2="0.642772" stroke="#C0C0C0" stroke-width="1.00975"/>
<circle cx="447.5" cy="441.5" r="163.995" stroke="#C0C0C0" stroke-width="1.00975"/>
<circle cx="447.911" cy="447.911" r="237.407" stroke="#C0C0C0" stroke-width="1.00975"/>
<circle cx="448" cy="442" r="384.495" stroke="#C0C0C0" stroke-width="1.00975"/>
</g>
</svg>
`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}
function useOptionalRef(ref) {
  const fallbackRef = useRef(null);
  if (ref && "instance" in ref) return fallbackRef;
  return ref ?? fallbackRef;
}
const CreatePolymorphicComponent = /* @__PURE__ */ forwardRef(
  // @ts-expect-error -- generic forwardRef signature doesn't propagate the As type param
  function CreatePolymorphicComponentRender({
    as,
    children,
    renderId,
    onError,
    ...rest
  }, forwardedRef) {
    const props = as === "img" ? {
      ...rest,
      // keep the original type of onError for <img>
      onError: (e) => {
        if (typeof onError === "function") onError(e);
        const img = e.currentTarget;
        const {
          width,
          height
        } = img.getBoundingClientRect();
        img.dataset.hasFallback = "1";
        img.onerror = null;
        img.src = buildGridPlaceholder(Math.round(width) || 128, Math.round(height) || 128);
        img.style.objectFit = "cover";
      }
    } : rest;
    const ref = useOptionalRef(forwardedRef);
    useEffect(() => {
      const el = ref && "current" in ref ? ref.current : null;
      if (!el) return;
      if (as !== "img") {
        const placeholder = () => {
          const {
            width,
            height
          } = el.getBoundingClientRect();
          return buildGridPlaceholder(Math.round(width) || 128, Math.round(height) || 128);
        };
        const applyBgFallback = () => {
          el.dataset.hasFallback = "1";
          el.style.backgroundImage = `url("${placeholder()}")`;
          el.style.backgroundSize = "cover";
        };
        const probeBg = () => {
          const bg = getComputedStyle(el).backgroundImage;
          const match = /url\(["']?(.+?)["']?\)/.exec(bg);
          const src = match?.[1];
          if (!src) return;
          const probe = new Image();
          probe.onerror = applyBgFallback;
          probe.src = src;
        };
        probeBg();
        const ro2 = new ResizeObserver(([entry]) => {
          if (!el.dataset.hasFallback) return;
          const {
            width,
            height
          } = entry.contentRect;
          el.style.backgroundImage = `url("${buildGridPlaceholder(Math.round(width) || 128, Math.round(height) || 128)}")`;
        });
        ro2.observe(el);
        const mo = new MutationObserver(probeBg);
        mo.observe(el, {
          attributes: true,
          attributeFilter: ["style", "class"]
        });
        return () => {
          ro2.disconnect();
          mo.disconnect();
        };
      }
      if (!el.dataset.hasFallback) return;
      const ro = new ResizeObserver(([entry]) => {
        const {
          width,
          height
        } = entry.contentRect;
        el.src = buildGridPlaceholder(Math.round(width) || 128, Math.round(height) || 128);
      });
      ro.observe(el);
      return () => ro.disconnect();
    }, [as, ref]);
    return /* @__PURE__ */ createElement(as, Object.assign({}, props, {
      ref,
      ...renderId ? {
        [JSX_RENDER_ID_ATTRIBUTE_NAME]: renderId
      } : void 0
    }), children);
  }
);

function LoadFonts() {
  return /* @__PURE__ */ jsx(Fragment, {});
}

function useDevServerHeartbeat() {
  useIdleTimer({
    disabled: typeof window === "undefined",
    throttle: 6e4 * 3,
    timeout: 6e4,
    onAction: () => {
      fetch("/", {
        method: "GET"
      }).catch((error) => {
      });
    }
  });
}

const links = () => [];
if (globalThis.window && globalThis.window !== void 0) {
  globalThis.window.fetch = fetchWithHeaders;
}
const LoadFontsSSR = LoadFonts ;
function InternalErrorBoundary({
  error: errorArg
}) {
  const routeError = useRouteError();
  const asyncError = useAsyncError();
  const error = errorArg ?? asyncError ?? routeError;
  const [isOpen, setIsOpen] = useState(false);
  const shouldScale = typeof window !== "undefined" ? window.innerWidth < 768 : false;
  const scaleFactor = shouldScale ? 1.02 : 1;
  const copyButtonTextClass = shouldScale ? "text-sm" : "text-xs";
  const copyButtonPaddingClass = shouldScale ? "px-[10px] py-[5px]" : "px-[6px] py-[3px]";
  const postCountRef = useRef(0);
  const lastPostTimeRef = useRef(0);
  const lastErrorKeyRef = useRef(null);
  const MAX_ERROR_POSTS_PER_ERROR = 5;
  const THROTTLE_MS = 1e3;
  useEffect(() => {
    const serialized = serializeError(error);
    const errorKey = JSON.stringify(serialized);
    if (errorKey !== lastErrorKeyRef.current) {
      lastErrorKeyRef.current = errorKey;
      postCountRef.current = 0;
    }
    if (postCountRef.current >= MAX_ERROR_POSTS_PER_ERROR) {
      return;
    }
    const now = Date.now();
    const timeSinceLastPost = now - lastPostTimeRef.current;
    const post = () => {
      if (postCountRef.current >= MAX_ERROR_POSTS_PER_ERROR) {
        return;
      }
      postCountRef.current += 1;
      lastPostTimeRef.current = Date.now();
      window.parent.postMessage({
        type: "sandbox:error:detected",
        error: serialized
      }, "*");
    };
    if (timeSinceLastPost < THROTTLE_MS) {
      const timer = setTimeout(post, THROTTLE_MS - timeSinceLastPost);
      return () => clearTimeout(timer);
    }
    post();
  }, [error]);
  useEffect(() => {
    const animateTimer = setTimeout(() => setIsOpen(true), 100);
    return () => clearTimeout(animateTimer);
  }, []);
  const {
    buttonProps: copyButtonProps
  } = useButton({
    onPress: useCallback(() => {
      const toastScale = shouldScale ? 1.2 : 1;
      const toastStyle = {
        padding: `${16 * toastScale}px`,
        background: "#18191B",
        border: "1px solid #2C2D2F",
        color: "white",
        borderRadius: "12px",
        boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)",
        width: `${280 * toastScale}px`,
        fontSize: `${13 * toastScale}px`,
        display: "flex",
        alignItems: "center",
        gap: `${6 * toastScale}px`,
        justifyContent: "flex-start",
        margin: "0 auto"
      };
      navigator.clipboard.writeText(JSON.stringify(serializeError(error)));
      toast.custom(() => /* @__PURE__ */ jsxs(CreatePolymorphicComponent, {
        style: toastStyle,
        renderId: "render-a52df4f3",
        as: "div",
        children: [/* @__PURE__ */ jsxs("svg", {
          xmlns: "http://www.w3.org/2000/svg",
          viewBox: "0 0 20 20",
          fill: "currentColor",
          height: "20",
          width: "20",
          children: [/* @__PURE__ */ jsx("title", {
            children: "Success"
          }), /* @__PURE__ */ jsx(CreatePolymorphicComponent, {
            fillRule: "evenodd",
            d: "M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z",
            clipRule: "evenodd",
            renderId: "render-19764128",
            as: "path"
          })]
        }), /* @__PURE__ */ jsx(CreatePolymorphicComponent, {
          renderId: "render-c09ed350",
          as: "span",
          children: "Copied successfully!"
        })]
      }), {
        id: "copy-error-success",
        duration: 3e3
      });
    }, [error, shouldScale])
  }, useRef(null));
  function isInIframe() {
    try {
      return window.parent !== window;
    } catch {
      return true;
    }
  }
  return /* @__PURE__ */ jsx(Fragment, {
    children: !isInIframe() && /* @__PURE__ */ jsx(CreatePolymorphicComponent, {
      className: `fixed bottom-4 left-1/2 transform -translate-x-1/2 max-w-md z-50 transition-all duration-500 ease-out ${isOpen ? "translate-y-0 opacity-100" : "translate-y-full opacity-0"}`,
      style: {
        width: "75vw"
      },
      renderId: "render-711ddc48",
      as: "div",
      children: /* @__PURE__ */ jsx(CreatePolymorphicComponent, {
        className: "bg-[#18191B] text-[#F2F2F2] rounded-lg p-4 shadow-lg w-full",
        style: scaleFactor !== 1 ? {
          transform: `scale(${scaleFactor})`,
          transformOrigin: "bottom center"
        } : void 0,
        renderId: "render-fcbe5720",
        as: "div",
        children: /* @__PURE__ */ jsxs(CreatePolymorphicComponent, {
          className: "flex items-start gap-3",
          renderId: "render-42091eec",
          as: "div",
          children: [/* @__PURE__ */ jsx(CreatePolymorphicComponent, {
            className: "flex-shrink-0",
            renderId: "render-559c7286",
            as: "div",
            children: /* @__PURE__ */ jsx(CreatePolymorphicComponent, {
              className: "w-8 h-8 bg-[#F2F2F2] rounded-full flex items-center justify-center",
              renderId: "render-0c6169fc",
              as: "div",
              children: /* @__PURE__ */ jsx(CreatePolymorphicComponent, {
                className: "text-black text-[1.125rem] leading-none",
                renderId: "render-4b4964e0",
                as: "span",
                children: "!"
              })
            })
          }), /* @__PURE__ */ jsxs(CreatePolymorphicComponent, {
            className: "flex flex-col gap-2 flex-1",
            renderId: "render-37a448a7",
            as: "div",
            children: [/* @__PURE__ */ jsxs(CreatePolymorphicComponent, {
              className: "flex flex-col gap-1",
              renderId: "render-f582a157",
              as: "div",
              children: [/* @__PURE__ */ jsx(CreatePolymorphicComponent, {
                className: "font-light text-[#F2F2F2] text-sm",
                renderId: "render-2ee0d2cf",
                as: "p",
                children: "App Error Detected"
              }), /* @__PURE__ */ jsx(CreatePolymorphicComponent, {
                className: "text-[#959697] text-sm font-light",
                renderId: "render-143f24e6",
                as: "p",
                children: "It looks like an error occurred while trying to use your app."
              })]
            }), /* @__PURE__ */ jsx(CreatePolymorphicComponent, {
              className: `flex flex-row items-center justify-center gap-[4px] outline-none transition-colors rounded-[8px] border-[1px] bg-[#2C2D2F] hover:bg-[#414243] active:bg-[#555658] border-[#414243] text-white ${copyButtonTextClass} ${copyButtonPaddingClass} w-fit`,
              type: "button",
              ...copyButtonProps,
              renderId: "render-a5ddcb2c",
              as: "button",
              children: "Copy error"
            })]
          })]
        })
      })
    })
  });
}
class ErrorBoundaryWrapper extends Component {
  state = {
    hasError: false,
    error: null
  };
  static getDerivedStateFromError(error) {
    return {
      hasError: true,
      error
    };
  }
  componentDidCatch(error, info) {
    console.error(error, info);
  }
  render() {
    if (this.state.hasError) {
      return /* @__PURE__ */ jsx(InternalErrorBoundary, {
        error: this.state.error,
        params: {}
      });
    }
    return this.props.children;
  }
}
function LoaderWrapper({
  loader
}) {
  return /* @__PURE__ */ jsx(Fragment, {
    children: loader()
  });
}
const ClientOnly = ({
  loader
}) => {
  const [isMounted, setIsMounted] = useState(false);
  useEffect(() => {
    setIsMounted(true);
  }, []);
  return /* @__PURE__ */ jsx(ErrorBoundaryWrapper, {
    children: isMounted ? /* @__PURE__ */ jsx(LoaderWrapper, {
      loader
    }) : null
  });
};
function useHmrConnection() {
  const [connected, setConnected] = useState(() => false);
  useEffect(() => {
    return;
  }, []);
  return connected;
}
const healthyResponseType = "sandbox:web:healthcheck:response";
const useHandshakeParent = () => {
  const isHmrConnected = useHmrConnection();
  useEffect(() => {
    const healthyResponse = {
      type: healthyResponseType,
      healthy: isHmrConnected,
      supportsErrorDetected: true
    };
    const handleMessage = (event) => {
      if (event.data.type === "sandbox:web:healthcheck") {
        window.parent.postMessage(healthyResponse, "*");
      }
    };
    window.addEventListener("message", handleMessage);
    window.parent.postMessage(healthyResponse, "*");
    return () => {
      window.removeEventListener("message", handleMessage);
    };
  }, [isHmrConnected]);
};
const waitForScreenshotReady = async () => {
  const images = Array.from(document.images);
  await Promise.all([
    // make sure custom fonts are loaded
    "fonts" in document ? document.fonts.ready : Promise.resolve(),
    ...images.map((img) => new Promise((resolve) => {
      img.crossOrigin = "anonymous";
      if (img.complete) {
        resolve(true);
        return;
      }
      img.onload = () => resolve(true);
      img.onerror = () => resolve(true);
    }))
  ]);
  await new Promise((resolve) => setTimeout(resolve, 250));
};
const useHandleScreenshotRequest = () => {
  useEffect(() => {
    const handleMessage = async (event) => {
      if (event.data.type === "sandbox:web:screenshot:request") {
        try {
          await waitForScreenshotReady();
          const width = window.innerWidth;
          const aspectRatio = 16 / 9;
          const height = Math.floor(width / aspectRatio);
          const dataUrl = await toPng(document.body, {
            cacheBust: true,
            skipFonts: false,
            width,
            height,
            style: {
              // force snapshot sizing
              width: `${width}px`,
              height: `${height}px`,
              margin: "0"
            }
          });
          window.parent.postMessage({
            type: "sandbox:web:screenshot:response",
            dataUrl
          }, "*");
        } catch (error) {
          window.parent.postMessage({
            type: "sandbox:web:screenshot:error",
            error: error instanceof Error ? error.message : String(error)
          }, "*");
        }
      }
    };
    window.addEventListener("message", handleMessage);
    return () => {
      window.removeEventListener("message", handleMessage);
    };
  }, []);
};
function Layout({
  children
}) {
  useHandshakeParent();
  useHandleScreenshotRequest();
  useDevServerHeartbeat();
  const navigate = useNavigate();
  const location = useLocation();
  const pathname = location?.pathname;
  const isMobile = typeof window !== "undefined" ? window.innerWidth < 768 : false;
  useEffect(() => {
    const handleMessage = (event) => {
      if (event.data.type === "sandbox:navigation") {
        navigate(event.data.pathname);
      }
    };
    window.addEventListener("message", handleMessage);
    window.parent.postMessage({
      type: "sandbox:web:ready"
    }, "*");
    return () => {
      window.removeEventListener("message", handleMessage);
    };
  }, [navigate]);
  useEffect(() => {
    if (pathname) {
      window.parent.postMessage({
        type: "sandbox:web:navigation",
        pathname
      }, "*");
    }
  }, [pathname]);
  return /* @__PURE__ */ jsxs("html", {
    lang: "en",
    children: [/* @__PURE__ */ jsxs("head", {
      children: [/* @__PURE__ */ jsx("meta", {
        charSet: "utf-8"
      }), /* @__PURE__ */ jsx("meta", {
        name: "viewport",
        content: "width=device-width, initial-scale=1"
      }), /* @__PURE__ */ jsx(Meta, {}), /* @__PURE__ */ jsx(Links, {}), /* @__PURE__ */ jsx("script", {
        type: "module",
        src: "/src/__create/dev-error-overlay.js"
      }), /* @__PURE__ */ jsx("link", {
        rel: "icon",
        href: "/src/__create/favicon.png"
      }), LoadFontsSSR ? /* @__PURE__ */ jsx(LoadFontsSSR, {}) : null]
    }), /* @__PURE__ */ jsxs("body", {
      children: [/* @__PURE__ */ jsx(ClientOnly, {
        loader: () => children
      }), /* @__PURE__ */ jsx(Toaster, {
        position: isMobile ? "top-center" : "bottom-right"
      }), /* @__PURE__ */ jsx(ScrollRestoration, {}), /* @__PURE__ */ jsx(Scripts, {}), /* @__PURE__ */ jsx("link", {
        rel: "preconnect",
        href: "https://ka-p.fontawesome.com",
        crossOrigin: "anonymous"
      }), /* @__PURE__ */ jsx("link", {
        rel: "stylesheet",
        href: "https://ka-p.fontawesome.com/releases/v6.3.0/css/pro.min.css?token=2c15cc0cc7",
        crossOrigin: "anonymous"
      })]
    })]
  });
}
const ErrorBoundary = UNSAFE_withErrorBoundaryProps(InternalErrorBoundary);
const root = UNSAFE_withComponentProps(function App() {
  return /* @__PURE__ */ jsx(SessionProvider, {
    children: /* @__PURE__ */ jsx(Outlet, {})
  });
});

const route0 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  ClientOnly,
  ErrorBoundary,
  Layout,
  default: root,
  links,
  useHandleScreenshotRequest,
  useHmrConnection
}, Symbol.toStringTag, { value: 'Module' }));

const serverManifest = {'entry':{'module':'/assets/entry.client-D5kiEPzi.js','imports':['/assets/chunk-5KNZJZUH-O4cCA1-k.js','/assets/index-BQZCNoY8.js'],'css':[]},'routes':{'root':{'id':'root','parentId':undefined,'path':'','index':undefined,'caseSensitive':undefined,'hasAction':false,'hasLoader':false,'hasClientAction':false,'hasClientLoader':false,'hasClientMiddleware':false,'hasDefaultExport':true,'hasErrorBoundary':true,'module':'/assets/root-BhVJyZMe.js','imports':['/assets/chunk-5KNZJZUH-O4cCA1-k.js','/assets/index-BQZCNoY8.js','/assets/index-BBR7LY95.js','/assets/PolymorphicComponent-l8XiAjgj.js','/assets/react-B2qFSgMy.js'],'css':['/assets/root-Di4mlaN3.css'],'clientActionModule':undefined,'clientLoaderModule':undefined,'clientMiddlewareModule':undefined,'hydrateFallbackModule':undefined},'page':{'id':'page','parentId':'root','path':undefined,'index':true,'caseSensitive':undefined,'hasAction':false,'hasLoader':false,'hasClientAction':false,'hasClientLoader':false,'hasClientMiddleware':false,'hasDefaultExport':true,'hasErrorBoundary':false,'module':'/assets/page-QTus7k66.js','imports':['/assets/page-DjwM0_eL.js','/assets/index-BBR7LY95.js','/assets/chunk-5KNZJZUH-O4cCA1-k.js','/assets/layout-5iR72Bj0.js'],'css':[],'clientActionModule':undefined,'clientLoaderModule':undefined,'clientMiddlewareModule':undefined,'hydrateFallbackModule':undefined},'admin/page':{'id':'admin/page','parentId':'root','path':'admin','index':undefined,'caseSensitive':undefined,'hasAction':false,'hasLoader':false,'hasClientAction':false,'hasClientLoader':false,'hasClientMiddleware':false,'hasDefaultExport':true,'hasErrorBoundary':false,'module':'/assets/page-BBIrlUjp.js','imports':['/assets/page-Bl2x8TPi.js','/assets/index-BBR7LY95.js','/assets/chunk-5KNZJZUH-O4cCA1-k.js','/assets/layout-5iR72Bj0.js','/assets/layout-CleBnzhb.js','/assets/PolymorphicComponent-l8XiAjgj.js','/assets/bundle-mjs-BE-CKRfa.js','/assets/trending-up-DXL3uWR2.js','/assets/circle-check-Bf5-txSW.js','/assets/zap-BxrK8_lI.js','/assets/file-down-1K-nhcfN.js','/assets/triangle-alert-wjTjwgd2.js','/assets/loader-circle-CTPcUZL3.js','/assets/trending-down-DfWH4EPq.js'],'css':[],'clientActionModule':undefined,'clientLoaderModule':undefined,'clientMiddlewareModule':undefined,'hydrateFallbackModule':undefined},'admin/audit/page':{'id':'admin/audit/page','parentId':'root','path':'admin/audit','index':undefined,'caseSensitive':undefined,'hasAction':false,'hasLoader':false,'hasClientAction':false,'hasClientLoader':false,'hasClientMiddleware':false,'hasDefaultExport':true,'hasErrorBoundary':false,'module':'/assets/page-oWlTnsKG.js','imports':['/assets/page-DWs2eMP-.js','/assets/index-BBR7LY95.js','/assets/chunk-5KNZJZUH-O4cCA1-k.js','/assets/layout-5iR72Bj0.js','/assets/layout-CleBnzhb.js','/assets/PolymorphicComponent-l8XiAjgj.js','/assets/bundle-mjs-BE-CKRfa.js','/assets/search-CsKNZowB.js'],'css':[],'clientActionModule':undefined,'clientLoaderModule':undefined,'clientMiddlewareModule':undefined,'hydrateFallbackModule':undefined},'admin/billing/page':{'id':'admin/billing/page','parentId':'root','path':'admin/billing','index':undefined,'caseSensitive':undefined,'hasAction':false,'hasLoader':false,'hasClientAction':false,'hasClientLoader':false,'hasClientMiddleware':false,'hasDefaultExport':true,'hasErrorBoundary':false,'module':'/assets/page-B73iaiJC.js','imports':['/assets/page-Dqc9JQ8x.js','/assets/index-BBR7LY95.js','/assets/chunk-5KNZJZUH-O4cCA1-k.js','/assets/layout-5iR72Bj0.js','/assets/layout-CleBnzhb.js','/assets/PolymorphicComponent-l8XiAjgj.js','/assets/bundle-mjs-BE-CKRfa.js','/assets/useMutation-Crh2DbZi.js','/assets/loader-circle-CTPcUZL3.js','/assets/file-down-1K-nhcfN.js','/assets/zap-BxrK8_lI.js','/assets/search-CsKNZowB.js','/assets/plus-EQ6w-LfI.js','/assets/circle-check-Bf5-txSW.js','/assets/clock-CLhBKh3p.js'],'css':[],'clientActionModule':undefined,'clientLoaderModule':undefined,'clientMiddlewareModule':undefined,'hydrateFallbackModule':undefined},'admin/grid/page':{'id':'admin/grid/page','parentId':'root','path':'admin/grid','index':undefined,'caseSensitive':undefined,'hasAction':false,'hasLoader':false,'hasClientAction':false,'hasClientLoader':false,'hasClientMiddleware':false,'hasDefaultExport':true,'hasErrorBoundary':false,'module':'/assets/page-BnzG0bCZ.js','imports':['/assets/page-D9Uu5m9Y.js','/assets/index-BBR7LY95.js','/assets/chunk-5KNZJZUH-O4cCA1-k.js','/assets/layout-5iR72Bj0.js','/assets/layout-CleBnzhb.js','/assets/PolymorphicComponent-l8XiAjgj.js','/assets/bundle-mjs-BE-CKRfa.js','/assets/useMutation-Crh2DbZi.js','/assets/zap-BxrK8_lI.js','/assets/trending-up-DXL3uWR2.js','/assets/trending-down-DfWH4EPq.js','/assets/loader-circle-CTPcUZL3.js'],'css':[],'clientActionModule':undefined,'clientLoaderModule':undefined,'clientMiddlewareModule':undefined,'hydrateFallbackModule':undefined},'admin/porter/page':{'id':'admin/porter/page','parentId':'root','path':'admin/porter','index':undefined,'caseSensitive':undefined,'hasAction':false,'hasLoader':false,'hasClientAction':false,'hasClientLoader':false,'hasClientMiddleware':false,'hasDefaultExport':true,'hasErrorBoundary':false,'module':'/assets/page-CVId8S-B.js','imports':['/assets/page-BlyOq1Xk.js','/assets/index-BBR7LY95.js','/assets/chunk-5KNZJZUH-O4cCA1-k.js','/assets/layout-5iR72Bj0.js','/assets/layout-CleBnzhb.js','/assets/PolymorphicComponent-l8XiAjgj.js','/assets/bundle-mjs-BE-CKRfa.js','/assets/useMutation-Crh2DbZi.js','/assets/plus-EQ6w-LfI.js','/assets/phone-DryENKjv.js','/assets/star-ByhcclwS.js'],'css':[],'clientActionModule':undefined,'clientLoaderModule':undefined,'clientMiddlewareModule':undefined,'hydrateFallbackModule':undefined},'admin/siptu/page':{'id':'admin/siptu/page','parentId':'root','path':'admin/siptu','index':undefined,'caseSensitive':undefined,'hasAction':false,'hasLoader':false,'hasClientAction':false,'hasClientLoader':false,'hasClientMiddleware':false,'hasDefaultExport':true,'hasErrorBoundary':false,'module':'/assets/page-6cLQhCuW.js','imports':['/assets/page-CwQcY_it.js','/assets/index-BBR7LY95.js','/assets/chunk-5KNZJZUH-O4cCA1-k.js','/assets/layout-5iR72Bj0.js','/assets/layout-CleBnzhb.js','/assets/PolymorphicComponent-l8XiAjgj.js','/assets/bundle-mjs-BE-CKRfa.js','/assets/useMutation-Crh2DbZi.js','/assets/plus-EQ6w-LfI.js','/assets/search-CsKNZowB.js','/assets/clock-CLhBKh3p.js','/assets/triangle-alert-wjTjwgd2.js','/assets/circle-check-Bf5-txSW.js'],'css':[],'clientActionModule':undefined,'clientLoaderModule':undefined,'clientMiddlewareModule':undefined,'hydrateFallbackModule':undefined},'admin/traders/page':{'id':'admin/traders/page','parentId':'root','path':'admin/traders','index':undefined,'caseSensitive':undefined,'hasAction':false,'hasLoader':false,'hasClientAction':false,'hasClientLoader':false,'hasClientMiddleware':false,'hasDefaultExport':true,'hasErrorBoundary':false,'module':'/assets/page-DYZrNHEZ.js','imports':['/assets/page-BNso7CAy.js','/assets/index-BBR7LY95.js','/assets/chunk-5KNZJZUH-O4cCA1-k.js','/assets/layout-5iR72Bj0.js','/assets/layout-CleBnzhb.js','/assets/PolymorphicComponent-l8XiAjgj.js','/assets/bundle-mjs-BE-CKRfa.js','/assets/useMutation-Crh2DbZi.js','/assets/plus-EQ6w-LfI.js','/assets/search-CsKNZowB.js','/assets/phone-DryENKjv.js','/assets/triangle-alert-wjTjwgd2.js','/assets/circle-check-Bf5-txSW.js'],'css':[],'clientActionModule':undefined,'clientLoaderModule':undefined,'clientMiddlewareModule':undefined,'hydrateFallbackModule':undefined},'errors/async-effect-error/page':{'id':'errors/async-effect-error/page','parentId':'root','path':'errors/async-effect-error','index':undefined,'caseSensitive':undefined,'hasAction':false,'hasLoader':false,'hasClientAction':false,'hasClientLoader':false,'hasClientMiddleware':false,'hasDefaultExport':true,'hasErrorBoundary':false,'module':'/assets/page-CQ-Uk5AS.js','imports':['/assets/page-C5ChGi5D.js','/assets/index-BBR7LY95.js','/assets/chunk-5KNZJZUH-O4cCA1-k.js','/assets/layout-5iR72Bj0.js','/assets/PolymorphicComponent-l8XiAjgj.js'],'css':[],'clientActionModule':undefined,'clientLoaderModule':undefined,'clientMiddlewareModule':undefined,'hydrateFallbackModule':undefined},'errors/event-handler-error/page':{'id':'errors/event-handler-error/page','parentId':'root','path':'errors/event-handler-error','index':undefined,'caseSensitive':undefined,'hasAction':false,'hasLoader':false,'hasClientAction':false,'hasClientLoader':false,'hasClientMiddleware':false,'hasDefaultExport':true,'hasErrorBoundary':false,'module':'/assets/page-DXh6s7dA.js','imports':['/assets/page-DuIMM_Jz.js','/assets/index-BBR7LY95.js','/assets/chunk-5KNZJZUH-O4cCA1-k.js','/assets/layout-5iR72Bj0.js','/assets/PolymorphicComponent-l8XiAjgj.js'],'css':[],'clientActionModule':undefined,'clientLoaderModule':undefined,'clientMiddlewareModule':undefined,'hydrateFallbackModule':undefined},'errors/hook-rule/page':{'id':'errors/hook-rule/page','parentId':'root','path':'errors/hook-rule','index':undefined,'caseSensitive':undefined,'hasAction':false,'hasLoader':false,'hasClientAction':false,'hasClientLoader':false,'hasClientMiddleware':false,'hasDefaultExport':true,'hasErrorBoundary':false,'module':'/assets/page-Yqwm5XAt.js','imports':['/assets/page--ni8bed1.js','/assets/index-BBR7LY95.js','/assets/chunk-5KNZJZUH-O4cCA1-k.js','/assets/layout-5iR72Bj0.js','/assets/PolymorphicComponent-l8XiAjgj.js'],'css':[],'clientActionModule':undefined,'clientLoaderModule':undefined,'clientMiddlewareModule':undefined,'hydrateFallbackModule':undefined},'errors/infinite-render-loop/page':{'id':'errors/infinite-render-loop/page','parentId':'root','path':'errors/infinite-render-loop','index':undefined,'caseSensitive':undefined,'hasAction':false,'hasLoader':false,'hasClientAction':false,'hasClientLoader':false,'hasClientMiddleware':false,'hasDefaultExport':true,'hasErrorBoundary':false,'module':'/assets/page-pW8qSADC.js','imports':['/assets/page-C0TVcu6K.js','/assets/index-BBR7LY95.js','/assets/chunk-5KNZJZUH-O4cCA1-k.js','/assets/layout-5iR72Bj0.js','/assets/PolymorphicComponent-l8XiAjgj.js'],'css':[],'clientActionModule':undefined,'clientLoaderModule':undefined,'clientMiddlewareModule':undefined,'hydrateFallbackModule':undefined},'errors/json-parse-error/page':{'id':'errors/json-parse-error/page','parentId':'root','path':'errors/json-parse-error','index':undefined,'caseSensitive':undefined,'hasAction':false,'hasLoader':false,'hasClientAction':false,'hasClientLoader':false,'hasClientMiddleware':false,'hasDefaultExport':true,'hasErrorBoundary':false,'module':'/assets/page-DBR8Bt86.js','imports':['/assets/page-97RasDwv.js','/assets/index-BBR7LY95.js','/assets/chunk-5KNZJZUH-O4cCA1-k.js','/assets/layout-5iR72Bj0.js','/assets/PolymorphicComponent-l8XiAjgj.js'],'css':[],'clientActionModule':undefined,'clientLoaderModule':undefined,'clientMiddlewareModule':undefined,'hydrateFallbackModule':undefined},'errors/missing-component/page':{'id':'errors/missing-component/page','parentId':'root','path':'errors/missing-component','index':undefined,'caseSensitive':undefined,'hasAction':false,'hasLoader':false,'hasClientAction':false,'hasClientLoader':false,'hasClientMiddleware':false,'hasDefaultExport':true,'hasErrorBoundary':false,'module':'/assets/page-CSGl9pD6.js','imports':['/assets/page-DtGavMle.js','/assets/index-BBR7LY95.js','/assets/chunk-5KNZJZUH-O4cCA1-k.js','/assets/layout-5iR72Bj0.js','/assets/PolymorphicComponent-l8XiAjgj.js'],'css':[],'clientActionModule':undefined,'clientLoaderModule':undefined,'clientMiddlewareModule':undefined,'hydrateFallbackModule':undefined},'errors/null-access/page':{'id':'errors/null-access/page','parentId':'root','path':'errors/null-access','index':undefined,'caseSensitive':undefined,'hasAction':false,'hasLoader':false,'hasClientAction':false,'hasClientLoader':false,'hasClientMiddleware':false,'hasDefaultExport':true,'hasErrorBoundary':false,'module':'/assets/page-BBfSPZwJ.js','imports':['/assets/page-peL0QWUq.js','/assets/index-BBR7LY95.js','/assets/chunk-5KNZJZUH-O4cCA1-k.js','/assets/layout-5iR72Bj0.js','/assets/PolymorphicComponent-l8XiAjgj.js'],'css':[],'clientActionModule':undefined,'clientLoaderModule':undefined,'clientMiddlewareModule':undefined,'hydrateFallbackModule':undefined},'errors/render-object/page':{'id':'errors/render-object/page','parentId':'root','path':'errors/render-object','index':undefined,'caseSensitive':undefined,'hasAction':false,'hasLoader':false,'hasClientAction':false,'hasClientLoader':false,'hasClientMiddleware':false,'hasDefaultExport':true,'hasErrorBoundary':false,'module':'/assets/page-NT8L5wP7.js','imports':['/assets/page-0XDDXSsd.js','/assets/index-BBR7LY95.js','/assets/chunk-5KNZJZUH-O4cCA1-k.js','/assets/layout-5iR72Bj0.js','/assets/PolymorphicComponent-l8XiAjgj.js'],'css':[],'clientActionModule':undefined,'clientLoaderModule':undefined,'clientMiddlewareModule':undefined,'hydrateFallbackModule':undefined},'errors/type-error-not-function/page':{'id':'errors/type-error-not-function/page','parentId':'root','path':'errors/type-error-not-function','index':undefined,'caseSensitive':undefined,'hasAction':false,'hasLoader':false,'hasClientAction':false,'hasClientLoader':false,'hasClientMiddleware':false,'hasDefaultExport':true,'hasErrorBoundary':false,'module':'/assets/page-C3fg05LI.js','imports':['/assets/page-DmVlaWNm.js','/assets/index-BBR7LY95.js','/assets/chunk-5KNZJZUH-O4cCA1-k.js','/assets/layout-5iR72Bj0.js','/assets/PolymorphicComponent-l8XiAjgj.js'],'css':[],'clientActionModule':undefined,'clientLoaderModule':undefined,'clientMiddlewareModule':undefined,'hydrateFallbackModule':undefined},'errors/undefined-access/page':{'id':'errors/undefined-access/page','parentId':'root','path':'errors/undefined-access','index':undefined,'caseSensitive':undefined,'hasAction':false,'hasLoader':false,'hasClientAction':false,'hasClientLoader':false,'hasClientMiddleware':false,'hasDefaultExport':true,'hasErrorBoundary':false,'module':'/assets/page-B3QaFcTs.js','imports':['/assets/page-BKssmZ0C.js','/assets/index-BBR7LY95.js','/assets/chunk-5KNZJZUH-O4cCA1-k.js','/assets/layout-5iR72Bj0.js','/assets/PolymorphicComponent-l8XiAjgj.js'],'css':[],'clientActionModule':undefined,'clientLoaderModule':undefined,'clientMiddlewareModule':undefined,'hydrateFallbackModule':undefined},'errors/unhandled-promise/page':{'id':'errors/unhandled-promise/page','parentId':'root','path':'errors/unhandled-promise','index':undefined,'caseSensitive':undefined,'hasAction':false,'hasLoader':false,'hasClientAction':false,'hasClientLoader':false,'hasClientMiddleware':false,'hasDefaultExport':true,'hasErrorBoundary':false,'module':'/assets/page-DRC5SV7p.js','imports':['/assets/page-MqRCSpr2.js','/assets/index-BBR7LY95.js','/assets/chunk-5KNZJZUH-O4cCA1-k.js','/assets/layout-5iR72Bj0.js','/assets/PolymorphicComponent-l8XiAjgj.js'],'css':[],'clientActionModule':undefined,'clientLoaderModule':undefined,'clientMiddlewareModule':undefined,'hydrateFallbackModule':undefined},'porter/page':{'id':'porter/page','parentId':'root','path':'porter','index':undefined,'caseSensitive':undefined,'hasAction':false,'hasLoader':false,'hasClientAction':false,'hasClientLoader':false,'hasClientMiddleware':false,'hasDefaultExport':true,'hasErrorBoundary':false,'module':'/assets/page-DEwoX5OK.js','imports':['/assets/page-DqxH6MtT.js','/assets/index-BBR7LY95.js','/assets/chunk-5KNZJZUH-O4cCA1-k.js','/assets/layout-5iR72Bj0.js','/assets/PolymorphicComponent-l8XiAjgj.js','/assets/bundle-mjs-BE-CKRfa.js','/assets/useMutation-Crh2DbZi.js','/assets/phone-DryENKjv.js','/assets/circle-check-Bf5-txSW.js','/assets/clock-CLhBKh3p.js','/assets/star-ByhcclwS.js','/assets/trending-up-DXL3uWR2.js','/assets/zap-BxrK8_lI.js','/assets/plus-EQ6w-LfI.js'],'css':[],'clientActionModule':undefined,'clientLoaderModule':undefined,'clientMiddlewareModule':undefined,'hydrateFallbackModule':undefined},'__create/social-dev-shim/page':{'id':'__create/social-dev-shim/page','parentId':'root','path':'__create/social-dev-shim','index':undefined,'caseSensitive':undefined,'hasAction':false,'hasLoader':false,'hasClientAction':false,'hasClientLoader':false,'hasClientMiddleware':false,'hasDefaultExport':true,'hasErrorBoundary':false,'module':'/assets/page-CDckq9go.js','imports':['/assets/page-CfsgAVfx.js','/assets/index-BBR7LY95.js','/assets/chunk-5KNZJZUH-O4cCA1-k.js','/assets/layout-5iR72Bj0.js','/assets/PolymorphicComponent-l8XiAjgj.js','/assets/react-B2qFSgMy.js'],'css':[],'clientActionModule':undefined,'clientLoaderModule':undefined,'clientMiddlewareModule':undefined,'hydrateFallbackModule':undefined},'__create/not-found':{'id':'__create/not-found','parentId':'root','path':'*?','index':undefined,'caseSensitive':undefined,'hasAction':false,'hasLoader':false,'hasClientAction':false,'hasClientLoader':false,'hasClientMiddleware':false,'hasDefaultExport':true,'hasErrorBoundary':false,'module':'/assets/not-found-DznQht_r.js','imports':['/assets/index-BBR7LY95.js','/assets/PolymorphicComponent-l8XiAjgj.js','/assets/chunk-5KNZJZUH-O4cCA1-k.js'],'css':[],'clientActionModule':undefined,'clientLoaderModule':undefined,'clientMiddlewareModule':undefined,'hydrateFallbackModule':undefined}},'url':'/assets/manifest-67e2de59.js','version':'67e2de59','sri':undefined};

const route1 = { default: () => null };
const route2 = { default: () => null };
const route3 = { default: () => null };
const route4 = { default: () => null };
const route5 = { default: () => null };
const route6 = { default: () => null };
const route7 = { default: () => null };
const route8 = { default: () => null };
const route9 = { default: () => null };
const route10 = { default: () => null };
const route11 = { default: () => null };
const route12 = { default: () => null };
const route13 = { default: () => null };
const route14 = { default: () => null };
const route15 = { default: () => null };
const route16 = { default: () => null };
const route17 = { default: () => null };
const route18 = { default: () => null };
const route19 = { default: () => null };
const route20 = { default: () => null };
const route21 = { default: () => null };
const route22 = { default: () => null };
      const assetsBuildDirectory = "build\\client";
      const basename = "/";
      const future = {"unstable_optimizeDeps":false,"v8_passThroughRequests":false,"unstable_trailingSlashAwareDataRequests":false,"unstable_previewServerPrerendering":false,"v8_middleware":false,"v8_splitRouteModules":false,"v8_viteEnvironmentApi":false};
      const ssr = false;
      const isSpaMode = true;
      const prerender = [];
      const routeDiscovery = {"mode":"initial"};
      const publicPath = "/";
      const entry = { module: entryServer };
      const routes = {
        "root": {
          id: "root",
          parentId: undefined,
          path: "",
          index: undefined,
          caseSensitive: undefined,
          module: route0
        },
  "page": {
          id: "page",
          parentId: "root",
          path: undefined,
          index: true,
          caseSensitive: undefined,
          module: route1
        },
  "admin/page": {
          id: "admin/page",
          parentId: "root",
          path: "admin",
          index: undefined,
          caseSensitive: undefined,
          module: route2
        },
  "admin/audit/page": {
          id: "admin/audit/page",
          parentId: "root",
          path: "admin/audit",
          index: undefined,
          caseSensitive: undefined,
          module: route3
        },
  "admin/billing/page": {
          id: "admin/billing/page",
          parentId: "root",
          path: "admin/billing",
          index: undefined,
          caseSensitive: undefined,
          module: route4
        },
  "admin/grid/page": {
          id: "admin/grid/page",
          parentId: "root",
          path: "admin/grid",
          index: undefined,
          caseSensitive: undefined,
          module: route5
        },
  "admin/porter/page": {
          id: "admin/porter/page",
          parentId: "root",
          path: "admin/porter",
          index: undefined,
          caseSensitive: undefined,
          module: route6
        },
  "admin/siptu/page": {
          id: "admin/siptu/page",
          parentId: "root",
          path: "admin/siptu",
          index: undefined,
          caseSensitive: undefined,
          module: route7
        },
  "admin/traders/page": {
          id: "admin/traders/page",
          parentId: "root",
          path: "admin/traders",
          index: undefined,
          caseSensitive: undefined,
          module: route8
        },
  "errors/async-effect-error/page": {
          id: "errors/async-effect-error/page",
          parentId: "root",
          path: "errors/async-effect-error",
          index: undefined,
          caseSensitive: undefined,
          module: route9
        },
  "errors/event-handler-error/page": {
          id: "errors/event-handler-error/page",
          parentId: "root",
          path: "errors/event-handler-error",
          index: undefined,
          caseSensitive: undefined,
          module: route10
        },
  "errors/hook-rule/page": {
          id: "errors/hook-rule/page",
          parentId: "root",
          path: "errors/hook-rule",
          index: undefined,
          caseSensitive: undefined,
          module: route11
        },
  "errors/infinite-render-loop/page": {
          id: "errors/infinite-render-loop/page",
          parentId: "root",
          path: "errors/infinite-render-loop",
          index: undefined,
          caseSensitive: undefined,
          module: route12
        },
  "errors/json-parse-error/page": {
          id: "errors/json-parse-error/page",
          parentId: "root",
          path: "errors/json-parse-error",
          index: undefined,
          caseSensitive: undefined,
          module: route13
        },
  "errors/missing-component/page": {
          id: "errors/missing-component/page",
          parentId: "root",
          path: "errors/missing-component",
          index: undefined,
          caseSensitive: undefined,
          module: route14
        },
  "errors/null-access/page": {
          id: "errors/null-access/page",
          parentId: "root",
          path: "errors/null-access",
          index: undefined,
          caseSensitive: undefined,
          module: route15
        },
  "errors/render-object/page": {
          id: "errors/render-object/page",
          parentId: "root",
          path: "errors/render-object",
          index: undefined,
          caseSensitive: undefined,
          module: route16
        },
  "errors/type-error-not-function/page": {
          id: "errors/type-error-not-function/page",
          parentId: "root",
          path: "errors/type-error-not-function",
          index: undefined,
          caseSensitive: undefined,
          module: route17
        },
  "errors/undefined-access/page": {
          id: "errors/undefined-access/page",
          parentId: "root",
          path: "errors/undefined-access",
          index: undefined,
          caseSensitive: undefined,
          module: route18
        },
  "errors/unhandled-promise/page": {
          id: "errors/unhandled-promise/page",
          parentId: "root",
          path: "errors/unhandled-promise",
          index: undefined,
          caseSensitive: undefined,
          module: route19
        },
  "porter/page": {
          id: "porter/page",
          parentId: "root",
          path: "porter",
          index: undefined,
          caseSensitive: undefined,
          module: route20
        },
  "__create/social-dev-shim/page": {
          id: "__create/social-dev-shim/page",
          parentId: "root",
          path: "__create/social-dev-shim",
          index: undefined,
          caseSensitive: undefined,
          module: route21
        },
  "__create/not-found": {
          id: "__create/not-found",
          parentId: "root",
          path: "*?",
          index: undefined,
          caseSensitive: undefined,
          module: route22
        }
      };
      
      const allowedActionOrigins = false;

export { allowedActionOrigins, serverManifest as assets, assetsBuildDirectory, basename, entry, future, isSpaMode, prerender, publicPath, routeDiscovery, routes, ssr };
